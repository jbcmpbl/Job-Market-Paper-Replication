To get your replication package up and running, you only need to do three things.

STEP 1: COPY THESE CONTENTS TO A FOLDER OF YOUR CHOICE
Your program will run entirely of your choice.

STEP 2: SETUP LATEX COMPILATION
1) Go into codes+data
2) Open up jacob_pathfinder.do
3) Change the file path for your Latex compilation to wherever you install it

STEP 3: RUN JACOB_REPLICATE
1) Go into your main folder
2) Run jacob_replicate.do
3) This produces everything

I cannot guarantee if this works for your specific version of Stata and Latex; it may call packages you don't have.

COMPLETE PACKAGE
replicate = Runs the whole package from shell folder
master = Runs the whole package from codes+data

INFRASTRUCTURE
transformer = Converts raw data to a working dataset; must be run (through replicate, master or by itself) at least once before other modules
pathfinder = Sets up path names; all modules call this (you never have to run this separately)

MODULES
regression = Runs regression specs and tables
summary = Runs summary stats
tables = Runs figures (yes, I know)
cartography = Runs maps
compile = Compiles the latex file
logger = Makes a date-and-time-stamped copy of the do-files
zipper = Makes the replication package

JACK-KNIFE
The jack-knife module could not be 100% automated; it spits out tables that have grammar that requires hand-correcting. Because of this, master and replicate don't run it: it would break the Latex PDF every time. I have provided the table output upfront. If you want to replicate jack-knife, run transformer, run jack-knife, hand correct its output files and then compile for viewing.

DATASETS
MotherFile = Raw dataset
UseData = Working dataset
Individual modules use their own copies of UseData