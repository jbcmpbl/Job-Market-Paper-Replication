global path "`c(pwd)'"
local original_dir "`c(pwd)'"

// Create subdirectories if they don't exist
cap mkdir "$path/codes+data"
cap mkdir "$path/figures"
cap mkdir "$path/legacy"
cap mkdir "$path/literature"
cap mkdir "$path/log"
cap mkdir "$path/tables"
cap mkdir "$path/zipper"

// Set sub-paths as globals
global path_data "$path/codes+data"
global path_figs "$path/figures"
global path_legacy "$path/legacy"
global path_literature "$path/literature"
global path_log "$path/log"
global path_tabs "$path/tables"
global path_zipper "$path/zipper"

// Set working directory
cd "$path_data"

di as result "Paths successfully set!"
di as text "Main path: $path"
di as text "Data path: $path_data"

// Also create locals for backward compatibility
local path "$path"
local path_data "$path_data"
local path_figs "$path_figs"
local path_legacy "$path_legacy"
local path_literature "$path_literature"
local path_log "$path_log"
local path_tabs "$path_tabs"
local path_zipper "$path_zipper"

do jacob_master

cd "$path_data"