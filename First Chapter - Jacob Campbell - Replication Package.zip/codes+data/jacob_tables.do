
******************************************
** Jacob: Setting paths, calling data **
******************************************

do "jacob_pathfinder.do"

// Also create locals for backward compatibility
local path "$path"
local path_data "$path_data"
local path_figs "$path_figs"
local path_legacy "$path_legacy"
local path_literature "$path_literature"
local path_log "$path_log"
local path_tabs "$path_tabs"
local path_zipper "$path_zipper"

	use UseData.dta, clear
	save UseDataTables.dta, replace
	use UseDataTables.dta, clear

*****************************

isid state year, sort
xtset state year
gen oecd=1

// Jacob (8/11/25): Temporary, not ideal for time series charts
// keep if decade==year


foreach x of varlist ypw_agg ypw_ag ypw_man ypw_nmna hcpw hcpw_ag hcpw_man hcpw_nmna kpw kpw_ag kpw_man kpw_nmna ky ky_ag ky_man ky_nmna tfp tfp_ag tfp_man tfp_nmna s_lf_ag s_lf_man s_lf_nmna {

local mylabel: variable label `x'

gen l`x'=log(`x')

gen gl`x'_ann = (l`x'-L.l`x')
gen l`x'0_ann = (L.l`x')

gen l`x'0= L10.l`x' 
label variable l`x'0 "Initial `mylabel' (decadal)"
gen gl`x' = (l`x'-L10.l`x')/10
label variable gl`x' "Growth of `mylabel' (decadal)"

forvalues y = 10(10)220 {
	gen gl`x'_Y`y' = (l`x'-L`y'.l`x')/`y'
	gen l`x'0_Y`y'= L`y'.l`x'
	
}

gen gl`x'_LR = 1
label variable gl`x'_LR "Growth of `mylabel' (long-run)"
gen l`x'_LR = 1
label variable l`x'_LR "Initial `mylabel' (long-run)"
 }
 
 *************************************************************************************
 ******** Convergence Scatter Poloyts (also in convergence.do) ***********************
 *************************************************************************************
 *************************************************************************************

 foreach x of varlist ypw_agg ypw_ag ypw_man ypw_nmna kpw kpw_ag kpw_man kpw_nmna hcpw hcpw_ag hcpw_man hcpw_nmna ky ky_ag ky_man ky_nmna tfp tfp_ag tfp_man tfp_nmna {

// TWO PERIOD LOOP

tw (scatter gl`x'_Y110 l`x'0_Y110 if  year==1910 & year==decade, mlabel(stateabv) ) (lfit  gl`x'_Y110 l`x'0_Y110 if  year==1910 & year==decade), legend(off) ///
title("Growth of GDP/worker vs. Initial Level (1800-1910)") ytitle("Avg. annual growth of GDP/worker") xtitle("Log of Initial GDP/worker") name(conv_`x'_1800_1910,replace) plotregion(fcolor(white)) graphregion(fcolor(white))

graph save "`path_figs'\conv_`x'_1800_1910.gph", replace

 tw (scatter gl`x'_Y110 l`x'0_Y110 if  year==2020 & year==decade, mlabel(stateabv) ) (lfit  gl`x'_Y110 l`x'0_Y110 if  year==2020 & year==decade), legend(off) ///
title("Growth of GDP/worker vs. Initial Level (1910-2020)") ytitle("Avg. annual growth of GDP/worker") xtitle("Log of Initial GDP/worker") name(conv_`x'_1910_2020,replace) plotregion(fcolor(white)) graphregion(fcolor(white))

graph save "`path_figs'\conv_`x'_1910_2020.gph", replace 

graph combine conv_`x'_1800_1910 conv_`x'_1910_2020, iscale(0.5)  col(2) plotregion(fcolor(white)) graphregion(fcolor(white))

graph save "`path_figs'\conv_`x'.gph", replace
graph export "`path_figs'\conv_`x'.png", replace

 tw (scatter gl`x' l`x'0 if  year<=1910 & year>1800 & year==decade, mlabel(stateabv)) (lfit  gl`x' l`x'0 if  year<=1910 & year>1800 & year==decade), legend(off) ///
title("Growth of GDP/worker vs. Initial Level (1800-1910)") ytitle("Avg. annual growth of GDP/worker") xtitle("Log Initial GDP/worker") name(conv_10yr_`x'_1800_1910,replace) plotregion(fcolor(white)) graphregion(fcolor(white))

graph save "`path_figs'\conv_10yr_`x'_1800_1910.gph", replace

 tw (scatter gl`x' l`x'0 if  year<=2020 & year>1910 & year==decade, mlabel(stateabv)) (lfit  gl`x' l`x'0 if  year<=2020 & year>1910 & year==decade), legend(off) ///
title("Growth of GDP/worker vs. Initial Level (1910-2020)") ytitle("Avg. annual growth of GDP/worker") xtitle("Log Initial GDP/worker") name(conv_10yr_`x'_1910_2020,replace) plotregion(fcolor(white)) graphregion(fcolor(white))

graph save "`path_figs'\conv_10yr_`x'_1910_2020.gph", replace

graph combine conv_10yr_`x'_1800_1910 conv_10yr_`x'_1910_2020, iscale(0.5)  col(2) plotregion(fcolor(white)) graphregion(fcolor(white))

graph save "`path_figs'\conv_10yr_`x'.gph", replace
graph export "`path_figs'\conv_10yr_`x'.png", replace

// BELOW IS AN ALTERNATE PERIODIZATION I NEVER USE
// THREE PERIOD LOOP
/*
tw (scatter glypw_agg_Y60 lypw_agg0_Y60 if  year==1860 & year==decade, mlabel(stateabv) ) (lfit  glypw_agg_Y60 lypw_agg0_Y60 if  year==1860 & year==decade), legend(off) ///
title("Growth of GDP/worker vs. Initial Level (1800-1860)") ytitle("Avg. annual growth of GDP/worker") xtitle("Log of Initial GDP/worker") name(conv_1800_1860,replace) plotregion(fcolor(white)) graphregion(fcolor(white))

graph save "`path_figs'\conv_1800_1860_three_period.gph", replace

 tw (scatter glypw_agg_Y50 lypw_agg0_Y50 if  year==1910 & year==decade, mlabel(stateabv) ) (lfit  glypw_agg_Y50 lypw_agg0_Y50 if  year==1910 & year==decade), legend(off) ///
title("Growth of GDP/worker vs. Initial Level (1860-1910)") ytitle("Avg. annual growth of GDP/worker") xtitle("Log of Initial GDP/worker") name(conv_1860_1910,replace) plotregion(fcolor(white)) graphregion(fcolor(white))

graph save "`path_figs'\conv_1860_1910_three_period.gph", replace

 tw (scatter glypw_agg_Y40 lypw_agg0_Y110 if  year==2020 & year==decade, mlabel(stateabv) ) (lfit  glypw_agg_Y110 lypw_agg0_Y110 if  year==2020 & year==decade), legend(off) ///
title("Growth of GDP/worker vs. Initial Level (1910-2020)") ytitle("Avg. annual growth of GDP/worker") xtitle("Log of Initial GDP/worker") name(conv_1910_2020,replace) plotregion(fcolor(white)) graphregion(fcolor(white))

graph save "`path_figs'\conv_1910_2020_three_period.gph", replace

graph combine  conv_1800_1860 ///
conv_1860_1910 ///
conv_1910_2020, iscale(0.5)  ycommon xcommon col(2) plotregion(fcolor(white)) graphregion(fcolor(white))


graph save "`path_figs'\conv_`x'_three_period.gph", replace
graph export "`path_figs'\conv_`x'_three_period.png", replace

 tw (scatter gl`x' l`x'0 if  year<=1860 & year>1800 & year==decade, mlabel(stateabv)) (lfit  gl`x' l`x'0 if  year<=1860 & year>1800 & year==decade), legend(off) ///
title("Growth of GDP/worker vs. Initial Level (1800-1860)") ytitle("Avg. annual growth of GDP/worker") xtitle("Log Initial GDP/worker") name(conv_10yr_1800_1860,replace) plotregion(fcolor(white)) graphregion(fcolor(white))

graph save "`path_figs'\conv_10yr_1800_1860_three_period.gph", replace

 tw (scatter gl`x' l`x'0 if  year<=1910 & year>1860 & year==decade, mlabel(stateabv)) (lfit  gl`x' l`x'0 if  year<=1910 & year>1860 & year==decade), legend(off) ///
title("Growth of GDP/worker vs. Initial Level (1860-1910)") ytitle("Avg. annual growth of GDP/worker") xtitle("Log Initial GDP/worker") name(conv_10yr_1860_1910,replace) plotregion(fcolor(white)) graphregion(fcolor(white))

graph save "`path_figs'\conv_10yr_1860_1910_three_period.gph", replace

 tw (scatter gl`x' l`x'0 if  year<=2020 & year>1910 & year==decade, mlabel(stateabv)) (lfit  gl`x' l`x'0 if  year<=2020 & year>1910 & year==decade), legend(off) ///
title("Growth of GDP/worker vs. Initial Level (1910-2020)") ytitle("Avg. annual growth of GDP/worker") xtitle("Log Initial GDP/worker") name(conv_10yr_1910_2020,replace) plotregion(fcolor(white)) graphregion(fcolor(white))

graph save "`path_figs'\conv_10yr_1910_2020_three_period.gph", replace

graph combine  conv_10yr_1800_1860 ///
conv_10yr_1860_1910 ///
conv_10yr_1910_2020, iscale(0.5)  ycommon xcommon col(2) plotregion(fcolor(white)) graphregion(fcolor(white))


graph save "`path_figs'\conv_10yr_`x'_three_period.gph", replace
graph export "`path_figs'\conv_10yr_`x'_three_period.png", replace
*/

}

 
// Jacob: These do the same as above but without a single data point for each state. Instead, they call every state's observation in every decade. Unfortunately, as noted above, the data blends from decadal to annual starting in 1929. I have added in & year==decade to force it all to be decadal for the meanwhile. The old stuff had several different graphs from different years (like from 1940, from 1960, etc.).

// Jacob: An additional graph I generated for annual data.

/*
 tw (scatter glypw_agg_ann lypw_agg0_ann if  year==2020, mlabel(stateabv) ) (lfit  glypw_agg_ann lypw_agg0_ann if  year==2020), legend(off) ///
title("Growth of GDP/worker vs. Initial Level (1929-2020)") ytitle("Avg. annual growth of GDP/worker") xtitle("Log of Initial GDP/worker")
graph save Graph "`path_figs'\conv_annual_1929_2020.gph", replace
 graph export "`path_figs'\conv_annual_1929-2020.png", replace
*/

*******************************************
// SIGMA CONVERGENCE FOR THE COMBINED PANEL
*******************************************

foreach x of varlist ypw_agg ypw_ag ypw_man ypw_nmna kpw kpw_ag kpw_man kpw_nmna ky ky_ag ky_man ky_nmna hcpw hcpw_ag hcpw_man hcpw_nmna tfp tfp_ag tfp_man tfp_nmna {

preserve
local ylab="`: var label `x' '"

// Create temporary files for each series
tempfile original_data unbalanced_data balanced1800_data balanced1850_data balanced1880_data balanced1950_data combined_data

// Save original data
save `original_data', replace

// Line 1: Unbalanced from 1800
use `original_data', clear
collapse (sd) sdy=l`x' (mean) avgy=l`x', by(year)
keep if year >= 1800 & year <= 2020
gen cvy = sdy/avgy
gen series = "Unbalanced 1800+"
gen series_num = 1
save `unbalanced_data', replace

// Line 2: Balanced from 1800
use `original_data', clear
bysort oecd: egen min_year = min(year) if !missing(l`x')
keep if in_1800==1
collapse (sd) sdy=l`x' (mean) avgy=l`x', by(year)
gen cvy = sdy/avgy
gen series = "Balanced 1800+"
gen series_num = 2
save `balanced1800_data', replace

// Line 3: Balanced from 1850
use `original_data', clear
bysort oecd: egen min_year = min(year) if !missing(l`x')
keep if in_1850==1
collapse (sd) sdy=l`x' (mean) avgy=l`x', by(year)
gen cvy = sdy/avgy
gen series = "Balanced 1850+"
replace cvy=. if year<1850
replace sdy=. if year<1850
gen series_num = 3
save `balanced1850_data', replace

// Line 4: Balanced from 1880
use `original_data', clear
bysort oecd: egen min_year = min(year) if !missing(l`x')
keep if in_1880==1
collapse (sd) sdy=l`x' (mean) avgy=l`x', by(year)
gen cvy = sdy/avgy
replace cvy=. if year<1880
replace sdy=. if year<1880
gen series = "Balanced 1880+"
gen series_num = 4
save `balanced1880_data', replace

// Line 5: Balanced from 1950
use `original_data', clear
bysort oecd: egen min_year = min(year) if !missing(l`x')
keep if in_1950==1
collapse (sd) sdy=l`x' (mean) avgy=l`x', by(year)
gen cvy = sdy/avgy
replace cvy=. if year<1950
replace sdy=. if year<1950
gen series = "Balanced 1950+"
gen series_num = 5
save `balanced1950_data', replace

// Combine all series
use `unbalanced_data', clear
append using `balanced1800_data'
append using `balanced1850_data'
append using `balanced1880_data'
append using `balanced1950_data'

// Graph for standard deviation
twoway ///
    (line sdy year if series_num==1, lcolor(black) lpattern(solid) lwidth(thick)) ///
    (line sdy year if series_num==2, lcolor(red) lpattern(dash) lwidth(medthick)) ///
    (line sdy year if series_num==3, lcolor(gray) lpattern(dot) lwidth(thick)) ///
    (line sdy year if series_num==4, lcolor(mint) lpattern(dash_dot) lwidth(medthick)) ///
    (line sdy year if series_num==5, lcolor(black) lpattern(solid) lwidth(thick)) ///
    , xline(1910, lpattern(shortdash) lcolor(gs10)) ///
    ytitle("Standard Deviation of `ylab'") ///
    xtitle("Year") ///
    title("{&sigma}-convergence (`ylab')") ///
    legend(order(1 "Unbalanced" 2 "Balanced 1800+" 3 "Balanced 1850+" 4 "Balanced 1880+" 5 "Balanced 1950+" ) ///
           position(6) rows(2) size(small)) ///
    scheme(s1color)

graph save "`path_figs'\sigma-conv-fivelines_`x'.gph", replace
graph export "`path_figs'\sigma-conv-fivelines_`x'.png", replace

// Graph for coefficient of variation
twoway ///
    (line cvy year if series_num==1, lcolor(black) lpattern(solid) lwidth(thick)) ///
    (line cvy year if series_num==2, lcolor(red) lpattern(dash) lwidth(medthick)) ///
    (line cvy year if series_num==3, lcolor(gray) lpattern(dot) lwidth(thick)) ///
    (line cvy year if series_num==4, lcolor(mint) lpattern(dash_dot) lwidth(medethick)) ///
    (line cvy year if series_num==5, lcolor(black) lpattern(solid) lwidth(thick)) ///
    , xline(1910, lpattern(shortdash) lcolor(gs10)) ///
    ytitle("Coefficient of Variation of `ylab'") ///
    xtitle("Year") ///
    title("{&sigma}-convergence (`ylab')") ///
    legend(order(1 "Unbalanced 1800+" 2 "Balanced 1800+" 3 "Balanced 1850+" 4 "Balanced 1880+" 5 "Balanced 1950+" ) ///
           position(6) rows(2) size(small)) ///
    scheme(s1color) ///

graph save "`path_figs'\sigma-cvy-conv-fivelines_`x'.gph", replace
graph export "`path_figs'\sigma-cvy-conv-fivelines_`x'.png", replace

restore
}

graph use "`path_figs'\sigma-conv-fivelines_ypw_agg.gph", name(gagg, replace)
graph use "`path_figs'\sigma-conv-fivelines_ypw_ag.gph", name(gag, replace)
graph use "`path_figs'\sigma-conv-fivelines_ypw_man.gph", name(gman, replace)
graph use "`path_figs'\sigma-conv-fivelines_ypw_nmna.gph", name(gnmna, replace)

graph combine  gagg ///
gag ///
gman ///
gnmna, iscale(0.4) xcommon ycommon col(2) plotregion(fcolor(white)) graphregion(fcolor(white))

graph save "`path_figs'\sigma-conv-fivelines.gph", replace
graph export "`path_figs'\sigma-conv-fivelines.png", replace



graph use "`path_figs'\sigma-conv-fivelines_kpw.gph", name(gaggk, replace)
graph use "`path_figs'\sigma-conv-fivelines_kpw_ag.gph", name(gagk, replace)
graph use "`path_figs'\sigma-conv-fivelines_kpw_man.gph", name(gmank, replace)
graph use "`path_figs'\sigma-conv-fivelines_kpw_nmna.gph", name(gnmnak, replace)

graph combine  gaggk ///
gagk ///
gmank ///
gnmnak, iscale(0.4) xcommon ycommon col(2) plotregion(fcolor(white)) graphregion(fcolor(white))

graph save "`path_figs'\sigma-conv-fivelines_kpw.gph", replace
graph export "`path_figs'\sigma-conv-fivelines_kpw.png", replace

 *************************************************************************************
 ******** Variance Plots *************************************************************
 *************************************************************************************
 *************************************************************************************

 
 // THIS WAS A ROBUSTNESS THAT GOT WAY OUT OF HAND, LOOKING FOR DIFFERENT WAYS OF BALANCING STANDARD DEVIATION AND COEFFICIENT OF VARIATION PANEL GRAPHS.
 // COMPLETELY UNNECESSARY, HORRIFIC. THE COMPOSITE "FIVELINES" IS GOOD ENOUGH.
/*
 forvalues z = 1800(10)2020{

foreach x of varlist ypw_agg ypw_ag ypw_man ypw_nmna kpw kpw_ag kpw_man kpw_nmna ky ky_ag ky_man ky_nmna hcpw hcpw_ag hcpw_man hcpw_nmna tfp tfp_ag tfp_man tfp_nmna {
 
preserve

drop if in_`z'==0

local ylab="`: var label `x' '"
collapse (sd) sdy=l`x' (mean) avgy=l`x', by(oecd year)
sort oecd year
xtset oecd year


gen cvy=sdy/avgy

xtline sdy if year>=1800 & year<=2020, xline(1910) overlay  ytitle("Std. dev. of Var. `ylab'") plot1opts(lp(solid) lw(medthick) ) title("{&sigma}-convergence (`ylab'): 1800-2020") plotregion(fcolor(white)) graphregion(fcolor(white))
graph save "`path_figs'\sigma-conv_`x'.gph", replace
graph use "`path_figs'\sigma-conv_`x'.gph"
graph export "`path_figs'\sigma-conv_`x'.png", replace

xtline cvy if year>=1800 & year<=2020, xline(1910) overlay  ytitle("Coeff. of Var. `ylab'") plot1opts(lp(solid) lw(medthick) ) title("{&sigma}-convergence (`ylab'): 1800-2020") plotregion(fcolor(white)) graphregion(fcolor(white))
graph save "`path_figs'\sigma-cvy-conv_`x'.gph", replace
graph use "`path_figs'\sigma-cvy-conv_`x'.gph"
graph export "`path_figs'\sigma-cvy-conv_`x'.png", replace

restore

}

foreach x of varlist edu_agg edu_ag edu_man edu_nmna lf_agg lf_ag lf_man lf_nmna avgage s_lf_ag s_lf_man s_lf_nmna {
 
preserve

local ylab="`: var label `x' '"
collapse (sd) sdy=`x' (mean) avgy=`x', by(oecd year)
sort oecd year
xtset oecd year
gen cvy=sdy/avgy

xtline sdy if year>=1800 & year<=2020, xline(1910) overlay  ytitle("Std. dev. of Var. `ylab'") plot1opts(lp(solid) lw(medthick) ) title("{&sigma}-convergence (`ylab'): 1800-2020") plotregion(fcolor(white)) graphregion(fcolor(white))
graph save "`path_figs'\sigma-conv_`x'.gph", replace
graph use "`path_figs'\sigma-conv_`x'.gph"
graph export "`path_figs'\sigma-conv_`x'.png", replace

xtline cvy if year>=1800 & year<=2020, xline(1910) overlay  ytitle("Coeff. of Var. `ylab'") plot1opts(lp(solid) lw(medthick) ) title("{&sigma}-convergence (`ylab'): 1800-2020") plotregion(fcolor(white)) graphregion(fcolor(white))
graph save "`path_figs'\sigma-cvy-conv_`x'.gph", replace
graph use "`path_figs'\sigma-cvy-conv_`x'.gph"
graph export "`path_figs'\sigma-cvy-conv_`x'.png", replace

restore

}

graph use "`path_figs'\sigma-conv_ypw_agg.gph", name(gagg, replace)
graph use "`path_figs'\sigma-conv_ypw_ag.gph", name(gag, replace)
graph use "`path_figs'\sigma-conv_ypw_man.gph", name(gman, replace)
graph use "`path_figs'\sigma-conv_ypw_nmna.gph", name(gnmna, replace)

graph combine  gagg ///
gag ///
gman ///
gnmna, iscale(0.4) xcommon ycommon col(2)

graph save "`path_figs'\sigma-conv.gph", replace
graph export "`path_figs'\sigma-conv.png", replace

graph combine gag ///
gman ///
gnmna, iscale(0.4) xcommon ycommon col(2)

graph save "`path_figs'\sigma-conv_secs.gph", replace
graph export "`path_figs'\sigma-conv_secs.png", replace


}


// Balanced panel from 1800

forvalues z = 1800(10)2010 {

foreach x of varlist ypw_agg ypw_ag ypw_man ypw_nmna kpw kpw_ag kpw_man kpw_nmna ky ky_ag ky_man ky_nmna hcpw hcpw_ag hcpw_man hcpw_nmna tfp tfp_ag tfp_man tfp_nmna {
 
preserve
keep if in_`z'==1

local ylab="`: var label `x' '"
collapse (sd) sdy=l`x' (mean) avgy=l`x', by(oecd year)
sort oecd year
xtset oecd year
gen cvy=sdy/avgy

xtline sdy if year>=`z' & year<=2020, xline(1910) overlay  ytitle("Std. dev. of Var. `ylab'") plot1opts(lp(solid) lw(medthick) ) title("{&sigma}-convergence (`ylab'): `z'-2020")
graph save "`path_figs'\sigma-conv_`x'_balanced_`z'.gph", replace
graph use "`path_figs'\sigma-conv_`x'_balanced_`z'.gph"
graph export "`path_figs'\sigma-conv_`x'_balanced_`z'.png", replace

xtline cvy if year>=`z' & year<=2020, xline(1910) overlay  ytitle("Coeff. of Var. `ylab'") plot1opts(lp(solid) lw(medthick) ) title("{&sigma}-convergence (`ylab'): `z'-2020")
graph save "`path_figs'\sigma-cvy-conv_`x'_balanced_`z'.gph", replace
graph use "`path_figs'\sigma-cvy-conv_`x'_balanced_`z'.gph"
graph export "`path_figs'\sigma-cvy-conv_`x'_balanced_`z'.png", replace

restore

}

graph use "`path_figs'\sigma-conv_ypw_agg_balanced_`z'.gph", name(gagg, replace)
graph use "`path_figs'\sigma-conv_ypw_ag_balanced_`z'.gph", name(gag, replace)
graph use "`path_figs'\sigma-conv_ypw_man_balanced_`z'.gph", name(gman, replace)
graph use "`path_figs'\sigma-conv_ypw_nmna_balanced_`z'.gph", name(gnmna, replace)

graph combine  gagg ///
gag ///
gman ///
gnmna, iscale(0.4) xcommon ycommon col(2)

graph save "`path_figs'\sigma-conv_balanced_`z'.gph", replace
graph export "`path_figs'\sigma-conv_balanced_`z'.png", replace

graph combine gag ///
gman ///
gnmna, iscale(0.4) xcommon ycommon col(2)

graph save "`path_figs'\sigma-conv_secs_balanced_`z'.gph", replace
graph export "`path_figs'\sigma-conv_secs_balanced_`z'.png", replace

}
// Moving balanced panel (census-divisional)


foreach x of varlist ypw_agg ypw_ag ypw_man ypw_nmna kpw kpw_ag kpw_man kpw_nmna ky ky_ag ky_man ky_nmna hcpw hcpw_ag hcpw_man hcpw_nmna tfp tfp_ag tfp_man tfp_nmna {
 
preserve

drop if census_div=="East South Central" & year<1820
drop if census_div=="East North Central" & year<1850
drop if census_div=="Pacific" & year<1870
drop if census_div=="South Atlantic" & year<1870
drop if census_div=="Mountain" & year<1900
drop if census_div=="West North Central" & year<1900
drop if census_div=="West South Central" & year<1920

local ylab="`: var label `x' '"
collapse (sd) sdy=l`x' (mean) avgy=l`x', by(oecd year)
sort oecd year
xtset oecd year
gen cvy=sdy/avgy

xtline sdy if year>=1800 & year<=2020, xline(1910) overlay  ytitle("Std. dev. of Var. `ylab'") plot1opts(lp(solid) lw(medthick) ) title("{&sigma}-convergence (`ylab'): 1800-2020")
graph save "`path_figs'\sigma-conv_`x'_balanced_mix.gph", replace
graph use "`path_figs'\sigma-conv_`x'_balanced_mix.gph"
graph export "`path_figs'\sigma-conv_`x'_balanced_mix.png", replace

xtline cvy if year>=1800 & year<=2020, xline(1910) overlay  ytitle("Coeff. of Var. `ylab'") plot1opts(lp(solid) lw(medthick) ) title("{&sigma}-convergence (`ylab'): 1800-2020")
graph save "`path_figs'\sigma-cvy-conv_`x'_balanced_mix.gph", replace
graph use "`path_figs'\sigma-cvy-conv_`x'_balanced_mix.gph"
graph export "`path_figs'\sigma-cvy-conv_`x'_balanced_mix.png", replace

restore

}

graph use "`path_figs'\sigma-conv_ypw_agg_balanced_mix.gph", name(gagg, replace)
graph use "`path_figs'\sigma-conv_ypw_ag_balanced_mix.gph", name(gag, replace)
graph use "`path_figs'\sigma-conv_ypw_man_balanced_mix.gph", name(gman, replace)
graph use "`path_figs'\sigma-conv_ypw_nmna_balanced_mix.gph", name(gnmna, replace)

graph combine  gagg ///
gag ///
gman ///
gnmna, iscale(0.4) xcommon ycommon col(2)

graph save "`path_figs'\sigma-conv_balanced_mix.gph", replace
graph export "`path_figs'\sigma-conv_balanced_mix.png", replace

graph combine gag ///
gman ///
gnmna, iscale(0.4) xcommon ycommon col(2)

graph save "`path_figs'\sigma-conv_secs_balanced_mix.gph", replace
graph export "`path_figs'\sigma-conv_secs_balanced_mix.png", replace

 *************************************************************************************
 ******** Variance Plots *************************************************************
 *************************************************************************************
 *************************************************************************************

foreach x of varlist s_lf_ag s_lf_man s_lf_nmna {
 
preserve

local ylab="`: var label `x' '"
collapse (sd) sdy=`x' (mean) avgy=`x', by(oecd year)
sort oecd year
xtset oecd year
gen cvy=sdy/avgy

xtline sdy if year>=1800 & year<=2020, xline(1860) xline(1910) overlay  ytitle("Std. dev. of Var. `ylab'") plot1opts(lp(solid) lw(medthick) ) title("{&sigma}-convergence (`ylab'): 1800-2020")
graph save "`path_figs'\sigma-conv_`x'.gph", replace
graph use "`path_figs'\sigma-conv_`x'.gph"
graph export "`path_figs'\sigma-conv_`x'.png", replace

xtline cvy if year>=1800 & year<=2020, xline(1860) xline(1910) overlay  ytitle("Coeff. of Var. `ylab'") plot1opts(lp(solid) lw(medthick) ) title("{&sigma}-convergence (`ylab'): 1800-2020")
graph save "`path_figs'\sigma-cvy-conv_`x'.gph", replace
graph use "`path_figs'\sigma-cvy-conv_`x'.gph"
graph export "`path_figs'\sigma-cvy-conv_`x'.png", replace

restore

}

graph use "`path_figs'\sigma-conv_s_lf_ag.gph", name(gag, replace)
graph use "`path_figs'\sigma-conv_s_lf_man.gph", name(gman, replace)
graph use "`path_figs'\sigma-conv_s_lf_nmna.gph", name(gnmna, replace)

graph combine gag ///
gman ///
gnmna, iscale(0.4) xcommon ycommon col(2)

graph save "`path_figs'\sigma-conv_s_lf.gph", replace
graph export "`path_figs'\sigma-conv_s_lf.png", replace

*/

 *************************************************************************************
 ******** Time Series Line Plots *****************************************************
 *************************************************************************************
 *************************************************************************************

// GENERATION OF GRAPHS (LABOR FORCE SHARES): BETWEEN CENSUS DIVISIONS

 foreach x of varlist s_lf_ag s_lf_man s_lf_nmna{

	preserve
	local ylab="`: var label `x' '"
	collapse (mean) `x', by(cen_div_num year)
	xtset cen_div_num year
	xtline `x', ytitle("`ylab'") title("`ylab':1800-2020 ") xline(1910) overlay name(bingbingwahoo,replace)
	graph save "`path_figs'\tslines_`x'.gph", replace
	graph export "`path_figs'\tslines_`x'.png", replace
	restore
 
 }
 
graph use "`path_figs'\tslines_s_lf_ag.gph", name(gag, replace)
graph use "`path_figs'\tslines_s_lf_man.gph", name(gman, replace)
graph use "`path_figs'\tslines_s_lf_nmna.gph", name(gnmna, replace)

graph combine gag ///
gman ///
gnmna, iscale(0.4) xcommon ycommon col(2)

graph save "`path_figs'\tslines_s_lf.gph", replace
graph export "`path_figs'\tslines_s_lf.png", replace

*/
 *************************************************************************************
 ******** Time Series Line Plots *****************************************************
 *************************************************************************************
 *************************************************************************************

// Jacob (8/17/25): This section just exists to let me call these in the for loops the way I want
rename experience work_agg
rename experience_ag work_ag 
rename experience_man work_man 
rename experience_nmna work_nmna 

foreach x of varlist ypw_agg ypw_ag ypw_man ypw_nmna kpw kpw_ag kpw_man kpw_nmna ky ky_ag ky_man ky_nmna hcpw hcpw_ag hcpw_man hcpw_nmna tfp tfp_ag tfp_man tfp_nmna edu_agg edu_ag edu_man edu_nmna work_agg work_ag work_man work_nmna avgage{
    local mylabel: variable label `x'
	label variable `x'_census "`mylabel'"
	label variable `x'_macro "`mylabel'"
}

// GENERATION OF GRAPHS (THINGS): BETWEEN CENSUS DIVISIONS
 
 foreach x of varlist ypw_agg_census ypw_ag_census ypw_man_census ypw_nmna_census kpw_census kpw_ag_census kpw_man_census kpw_nmna_census ky_census ky_ag_census ky_man_census ky_nmna_census hcpw_census hcpw_ag_census hcpw_man_census hcpw_nmna_census tfp_census tfp_ag_census tfp_man_census tfp_nmna_census{

	preserve
	local ylab="`: var label `x' '"
	collapse (mean) `x', by(cen_div_num year)
	xtset cen_div_num year
	xtline `x', ytitle("`ylab'") title("Convergence (`ylab'):1800-2020 ") xline(1910) ysc(log) overlay name(bingbingwahoo,replace) plotregion(fcolor(white)) graphregion(fcolor(white))
	graph export "`path_figs'\tslines_`x'.png", name(bingbingwahoo) replace
	restore
 
 }

// GENERATION OF GRAPHS (THINGS): WITHIN CENSUS DIVISIONS
 
 foreach y in 1 2 3 4 5 6 7 8 9 {
 	local ylab : label (cen_div_num) `y'
 	foreach x of varlist ypw_agg ypw_ag ypw_man ypw_nmna kpw kpw_ag kpw_man kpw_nmna ky ky_ag ky_man ky_nmna hcpw hcpw_ag hcpw_man hcpw_nmna tfp tfp_ag tfp_man tfp_nmna{
		xtset state year
		local xlab="`: var label `x' '"
		xtline `x' if cen_div_num==`y',  ytitle("`xlab'") title("Convergence (`xlab') among (`ylab'):1800-2020") xline(1910) ysc(log) overlay plotregion(fcolor(white)) graphregion(fcolor(white))
		graph export "`path_figs'\tslines_`x'_among_`ylab'.png", replace
	}
 }

// GENERATION OF GRAPHS (THINGS): BETWEEN MACRO DIVISIONS
 
 foreach y in 1 2 3 {
 	local ylab : label (macro_div) `y'
 	foreach x of varlist ypw_agg ypw_ag ypw_man ypw_nmna kpw kpw_ag kpw_man kpw_nmna ky ky_ag ky_man ky_nmna hcpw hcpw_ag hcpw_man hcpw_nmna tfp tfp_ag tfp_man tfp_nmna{
		preserve
		xtset state year		
		local xlab="`: var label `x' '"
		xtline `x' if macro_div==`y',  ytitle("`xlab'") title("Convergence (`xlab') among (`ylab'):1800-2020") xline(1910) overlay plotregion(fcolor(white)) graphregion(fcolor(white))
		graph export "`path_figs'\tslines_`x'_among_`ylab'.png", replace
		restore
	}
 }
 
// GENERATION OF GRAPHS (HUMANS): BETWEEN CENSUS DIVISIONS

 foreach x of varlist edu_agg_census edu_ag_census edu_man_census edu_nmna_census work_agg_census work_ag_census work_man_census work_nmna_census avgage_census s_lf_ag s_lf_man s_lf_nmna {
	preserve
	local ylab="`: var label `x' '"
	collapse (mean) `x', by(cen_div_num year)
	xtset cen_div_num year
	xtline `x', ytitle("`ylab'") title("Convergence (`ylab'):1800-2020 ") xline(1910) overlay name(bingbingwahoo,replace) plotregion(fcolor(white)) graphregion(fcolor(white))
	graph export "`path_figs'\tslines_`x'.png", name(bingbingwahoo) replace
	restore
 }

// GENERATION OF GRAPHS (HUMANS): WITHIN CENSUS DIVISIONS

 foreach y in 1 2 3 4 5 6 7 8 9 {
 	local ylab : label (cen_div_num) `y'
 	foreach x of varlist edu_agg edu_ag edu_man edu_nmna work_agg work_ag work_man work_nmna avgage s_lf_ag s_lf_man s_lf_nmna {
		xtset state year
		local xlab="`: var label `x' '"
		xtline `x' if cen_div_num==`y',  ytitle("`xlab'") title("Convergence (`xlab') among (`ylab'):1800-2020") xline(1910) overlay plotregion(fcolor(white)) graphregion(fcolor(white))
		graph export "`path_figs'\tslines_`x'_among_`ylab'.png", replace
	}
 }

// GENERATION OF GRAPHS (HUMANS): BETWEEN MACRO DIVISIONS

 foreach y in 1 2 3 {
	local ylab : label (macro_div) `y'
 	foreach x of varlist edu_agg edu_ag edu_man edu_nmna work_agg work_ag work_man work_nmna avgage s_lf_ag s_lf_man s_lf_nmna {
	    preserve
		xtset state year
		local xlab="`: var label `x' '"
		xtline `x' if macro_div==`y',  ytitle("`xlab'") title("Convergence (`xlab') among (`ylab'):1800-2020") xline(1910) overlay plotregion(fcolor(white)) graphregion(fcolor(white))
		graph export "`path_figs'\tslines_`x'_among_`ylab'.png", replace
	restore
	}
 }
 
 cd "$path_data"
