
******************************************
** Jacob: Setting paths, calling data **
******************************************

do "jacob_pathfinder.do"

// Also create locals for backward compatibility
local path "$path"
local path_data "$path_data"
local path_figs "$path_figs"
local path_legacy "$path_legacy"
local path_literature "$path_literature"
local path_log "$path_log"
local path_tabs "$path_tabs"
local path_zipper "$path_zipper"

ssc install listtab

	use UseData.dta, clear

preserve

drop if year!=decade
drop if ypw_agg==.

estpost summarize ypw_agg ypw_ag ypw_man ypw_nmna lf_agg lf_ag lf_man lf_nmna s_lf_agg s_lf_ag s_lf_man s_lf_nmna first_decade avgage edu_agg edu_ag edu_man edu_nmna experience experience_ag experience_man experience_nmna hcpw hcpw_ag hcpw_man hcpw_nmna tfp tfp_ag tfp_man tfp_nmna ky ky_ag ky_man ky_nmna kpw kpw_ag kpw_man kpw_nmna, detail
esttab using "`path_tabs'/summary_desc.tex", replace ///
    booktabs nonumber noobs label nomtitles nonotes ///
	cells("count(fmt(0)) mean(fmt(3)) sd(fmt(3)) min(fmt(3)) max(fmt(3))") ///
    collabels("N" "Mean" "SD" "Min" "Max")
restore

preserve

drop if year!=decade
drop if ypw_agg==.
keep if year<=1910

estpost summarize ypw_agg ypw_ag ypw_man ypw_nmna lf_agg lf_ag lf_man lf_nmna s_lf_agg s_lf_ag s_lf_man s_lf_nmna first_decade avgage edu_agg edu_ag edu_man edu_nmna experience experience_ag experience_man experience_nmna hcpw hcpw_ag hcpw_man hcpw_nmna tfp tfp_ag tfp_man tfp_nmna ky ky_ag ky_man ky_nmna kpw kpw_ag kpw_man kpw_nmna, detail
esttab using "`path_tabs'/summary_desc_first_period.tex", replace ///
    booktabs nonumber noobs label nomtitles nonotes ///
	cells("count(fmt(0)) mean(fmt(3)) sd(fmt(3)) min(fmt(3)) max(fmt(3))") ///
    collabels("N" "Mean" "SD" "Min" "Max")

restore

preserve

drop if year!=decade
drop if ypw_agg==.
keep if year>=1910

estpost summarize ypw_agg ypw_ag ypw_man ypw_nmna lf_agg lf_ag lf_man lf_nmna s_lf_agg s_lf_ag s_lf_man s_lf_nmna first_decade avgage edu_agg edu_ag edu_man edu_nmna experience experience_ag experience_man experience_nmna hcpw hcpw_ag hcpw_man hcpw_nmna tfp tfp_ag tfp_man tfp_nmna ky ky_ag ky_man ky_nmna kpw kpw_ag kpw_man kpw_nmna, detail
esttab using "`path_tabs'/summary_desc_second_period.tex", replace ///
    booktabs nonumber noobs label nomtitles nonotes ///
	cells("count(fmt(0)) mean(fmt(3)) sd(fmt(3)) min(fmt(3)) max(fmt(3))") ///
    collabels("N" "Mean" "SD" "Min" "Max")

restore

preserve

drop if year!=2020
keep stateabv first_decade in_1800 in_1850 in_1880
sort stateabv

gen in1800check = cond(in_1800 == 1, "\checkmark", "")
gen in1850check = cond(in_1850 == 1, "\checkmark", "")
gen in1880check = cond(in_1880 == 1, "\checkmark", "")

listtab stateabv first_decade in1800check in1850check in1880check using "`path_tabs'/state_first_coverage.tex", replace ///
    rstyle(tabular) ///
    head("\begin{tabular}{lcccc}\toprule State & First decade & Included in 1800 & Included in 1850 & Included in 1880 \\ \midrule") ///
    foot("\bottomrule\end{tabular}")

restore

	/*
 stateabv state statealp statehood_year id census_div macro_div ypw_agg ypw_ag ypw_man ypw_nmna lf_agg lf_ag lf_man lf_nmna s_lf_agg s_lf_ag s_lf_man s_lf_nmna decade first_decade is_first_decade appears year avgage cen_div_num edu_agg edu_ag edu_man edu_nmna experience experience_ag experience_man experience_nmna hcpw hcpw_ag hcpw_man hcpw_nmna tfp tfp_ag tfp_man tfp_nmna ky ky_ag ky_man ky_nmna kpw kpw_ag kpw_man kpw_nmna

save UseData.dta, replace
*/

cd "$path_data"