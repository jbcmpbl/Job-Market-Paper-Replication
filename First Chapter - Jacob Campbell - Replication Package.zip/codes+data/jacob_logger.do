
******************************************
** Jacob: Setting paths, calling data **
******************************************

do "jacob_pathfinder.do"

// Also create locals for backward compatibility
local path "$path"
local path_data "$path_data"
local path_figs "$path_figs"
local path_legacy "$path_legacy"
local path_literature "$path_literature"
local path_log "$path_log"
local path_tabs "$path_tabs"
local path_zipper "$path_zipper"

local bases cartography convergence logger master summary tables transformer zipper compile jackknife

foreach b of local bases {
    local src "jacob_`b'.do"
	local today  : display %tdCCYY-NN-DD date("`c(current_date)'","DMY")
	local time = subinstr("`c(current_time)'", ":", "-", .)
	local dst "`path_log'\jacob_`b'_`today'_`time'.do"
	copy "`src'" "`dst'", replace
}

cd "$path"

local src "jacob_replicate.do"
local today  : display %tdCCYY-NN-DD date("`c(current_date)'","DMY")
local time = subinstr("`c(current_time)'", ":", "-", .)
local dst "`path_log'\jacob_replicate_`today'_`time'.do"
copy "`src'" "`dst'", replace

cd "$path_data"