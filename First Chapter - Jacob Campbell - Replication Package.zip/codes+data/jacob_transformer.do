
******************************************
** Jacob: Setting paths, calling data **
******************************************

do "jacob_pathfinder.do"

// Also create locals for backward compatibility
local path "$path"
local path_data "$path_data"
local path_figs "$path_figs"
local path_legacy "$path_legacy"
local path_literature "$path_literature"
local path_log "$path_log"
local path_tabs "$path_tabs"
local path_zipper "$path_zipper"

use MotherFile.dta, clear
save UseData.dta, replace
use UseData.dta, clear

gen stateabv=""
label variable stateabv "State abbreviation"
replace stateabv="AL" if state==1
replace stateabv="AK" if state==2
replace stateabv="AZ" if state==3
replace stateabv="AR" if state==4
replace stateabv="CA" if state==5
replace stateabv="CO" if state==6
replace stateabv="CT" if state==7
replace stateabv="DE" if state==8
replace stateabv="FL" if state==10
replace stateabv="GA" if state==11
replace stateabv="HI" if state==12
replace stateabv="ID" if state==13
replace stateabv="IL" if state==14
replace stateabv="IN" if state==15
replace stateabv="IA" if state==16
replace stateabv="KS" if state==17
replace stateabv="KY" if state==18
replace stateabv="LA" if state==19
replace stateabv="ME" if state==20
replace stateabv="MD" if state==21
replace stateabv="MA" if state==22
replace stateabv="MI" if state==23
replace stateabv="MN" if state==24
replace stateabv="MS" if state==25
replace stateabv="MO" if state==26
replace stateabv="MT" if state==27
replace stateabv="NE" if state==28
replace stateabv="NV" if state==29
replace stateabv="NH" if state==30
replace stateabv="NJ" if state==31
replace stateabv="NM" if state==32
replace stateabv="NY" if state==33
replace stateabv="NC" if state==34
replace stateabv="ND" if state==35
replace stateabv="OH" if state==36
replace stateabv="OK" if state==37
replace stateabv="OR" if state==38
replace stateabv="PA" if state==39
replace stateabv="RI" if state==40
replace stateabv="SC" if state==41
replace stateabv="SD" if state==42
replace stateabv="TN" if state==43
replace stateabv="TX" if state==44
replace stateabv="UT" if state==45
replace stateabv="VT" if state==46
replace stateabv="VA" if state==47
replace stateabv="WA" if state==48
replace stateabv="WV" if state==49
replace stateabv="WI" if state==50
replace stateabv="WY" if state==51

drop if missing(state)

merge m:1 stateabv using "jacob_WorkerAge.dta"
replace avgage=value_2010 if missing(avgage) & year==2010
replace avgage=value_2020 if missing(avgage) & year==2020
drop value_2010
drop value_2020

gen statehood_year=0
replace statehood_year=1787 if statealp=="delaware"
replace statehood_year=1787 if statealp=="pennsylvania"
replace statehood_year=1787 if statealp=="new jersey"
replace statehood_year=1788 if statealp=="georgia"
replace statehood_year=1788 if statealp=="connecticut"
replace statehood_year=1788 if statealp=="massachusetts"
replace statehood_year=1788 if statealp=="maryland"
replace statehood_year=1788 if statealp=="south carolina"
replace statehood_year=1788 if statealp=="new hampshire"
replace statehood_year=1788 if statealp=="virginia"
replace statehood_year=1788 if statealp=="new york"
replace statehood_year=1789 if statealp=="north carolina"
replace statehood_year=1790 if statealp=="rhode island"
replace statehood_year=1791 if statealp=="vermont"
replace statehood_year=1792 if statealp=="kentucky"
replace statehood_year=1796 if statealp=="tennessee"
replace statehood_year=1803 if statealp=="ohio"
replace statehood_year=1812 if statealp=="louisiana"
replace statehood_year=1816 if statealp=="indiana"
replace statehood_year=1817 if statealp=="mississippi"
replace statehood_year=1818 if statealp=="illinois"
replace statehood_year=1819 if statealp=="alabama"
replace statehood_year=1820 if statealp=="maine"
replace statehood_year=1821 if statealp=="missouri"
replace statehood_year=1836 if statealp=="arkansas"
replace statehood_year=1837 if statealp=="michigan"
replace statehood_year=1845 if statealp=="florida"
replace statehood_year=1845 if statealp=="texas"
replace statehood_year=1846 if statealp=="iowa"
replace statehood_year=1848 if statealp=="wisconsin"
replace statehood_year=1850 if statealp=="california"
replace statehood_year=1858 if statealp=="minnesota"
replace statehood_year=1859 if statealp=="oregon"
replace statehood_year=1861 if statealp=="kansas"
replace statehood_year=1863 if statealp=="west virginia"
replace statehood_year=1864 if statealp=="nevada"
replace statehood_year=1867 if statealp=="nebraska"
replace statehood_year=1876 if statealp=="colorado"
replace statehood_year=1889 if statealp=="north dakota"
replace statehood_year=1889 if statealp=="south dakota"
replace statehood_year=1889 if statealp=="montana"
replace statehood_year=1889 if statealp=="washington"
replace statehood_year=1890 if statealp=="idaho"
replace statehood_year=1890 if statealp=="wyoming"
replace statehood_year=1896 if statealp=="utah"
replace statehood_year=1907 if statealp=="oklahoma"
replace statehood_year=1912 if statealp=="new mexico"
replace statehood_year=1912 if statealp=="arizona"
replace statehood_year=1959 if statealp=="alaska"
replace statehood_year=1959 if statealp=="hawaii"

gen statehood_decade=floor(statehood_year/10)*10 + 10

gen census_div=""
label variable census_div "Census division"
replace census_div="East South Central" if state==1
replace census_div="Pacific" if state==2
replace census_div="Mountain" if state==3
replace census_div="West South Central" if state==4
replace census_div="Pacific" if state==5
replace census_div="Mountain" if state==6
replace census_div="New England" if state==7
replace census_div="South Atlantic" if state==8
replace census_div="South Atlantic" if state==10
replace census_div="South Atlantic" if state==11
replace census_div="Pacific" if state==12
replace census_div="Mountain" if state==13
replace census_div="East North Central" if state==14
replace census_div="East North Central" if state==15
replace census_div="West North Central" if state==16
replace census_div="West North Central" if state==17
replace census_div="East South Central" if state==18
replace census_div="West South Central" if state==19
replace census_div="New England" if state==20
replace census_div="South Atlantic" if state==21
replace census_div="New England" if state==22
replace census_div="East North Central" if state==23
replace census_div="West North Central" if state==24
replace census_div="East South Central" if state==25
replace census_div="West North Central" if state==26
replace census_div="Mountain" if state==27
replace census_div="West North Central" if state==28
replace census_div="Mountain" if state==29
replace census_div="New England" if state==30
replace census_div="Mid Atlantic" if state==31
replace census_div="Mountain" if state==32
replace census_div="Mid Atlantic" if state==33
replace census_div="South Atlantic" if state==34
replace census_div="West North Central" if state==35
replace census_div="East North Central" if state==36
replace census_div="West South Central" if state==37
replace census_div="Pacific" if state==38
replace census_div="Mid Atlantic" if state==39
replace census_div="New England" if state==40
replace census_div="South Atlantic" if state==41
replace census_div="West North Central" if state==42
replace census_div="East South Central" if state==43
replace census_div="West South Central" if state==44
replace census_div="Mountain" if state==45
replace census_div="New England" if state==46
replace census_div="South Atlantic" if state==47
replace census_div="Pacific" if state==48
replace census_div="South Atlantic" if state==49
replace census_div="East North Central" if state==50
replace census_div="Mountain" if state==51

drop ypw_nmna
drop lf_nmna 
drop lf_man

rename kpw_ind kpw_man 
rename ypw_ind ypw_man 
rename lf_ind lf_man

rename kpw_services kpw_nmna 
rename ypw_services ypw_nmna
rename lf_services lf_nmna
rename exp experience

drop s_lf_ag
drop s_lf_man
drop s_lf_nmna 

gen s_lf_agg=1
gen s_lf_ag=lf_ag/lf_agg
gen s_lf_man=lf_man/lf_agg 
gen s_lf_nmna=lf_nmna/lf_agg

// Data cleaning
// drop if statealp=="california" & year<1860 // Dropped because of the bizarre issue with the labor force calculations

gen decade = floor(year/10)*10
egen nonmiss = rownonmiss(ypw_agg ypw_ag ypw_man ypw_nmna)
bysort state decade: egen has_obs_dec = max(nonmiss>0)
bysort state: egen first_decade = min(cond(has_obs_dec, decade, .))
gen byte is_first_decade = (decade == first_decade) if !missing(first_decade)
label var first_decade "Earliest decade"
label var is_first_decade "Indictator: earliest decade for this state"
drop nonmiss has_obs_dec

gen appears=""
replace appears="early" if statehood_decade>first_decade
replace appears="late" if statehood_decade<first_decade
replace appears="on time" if statehood_decade==first_decade

sort state year
replace avgage = avgage[_n+1] if avgage==. & ypw_agg!=. & year==decade & year<1850
replace avgage = avgage[_n+1] if avgage==. & ypw_agg!=. & year==decade & year<1850
replace avgage = avgage[_n+1] if avgage==. & ypw_agg!=. & year==decade & year<1850
replace avgage = avgage[_n+1] if avgage==. & ypw_agg!=. & year==decade & year<1850

encode census_div, gen(cen_div_num)
drop state
encode stateabv, gen(state)

local alpha=0.33

sort state year 
xtset state year 

// Jacob (7/9/25): Formula given to me by Tamura by email of July 7.
// Jacob (8/12/25): Explicitly told by Jerzmanowski to use a weighted average for aggregate.
drop edu_agg
gen edu_agg = s_lf_ag*edu_ag + s_lf_man*edu_man + s_lf_nmna*edu_nmna

gen experience_ag = avgage-edu_ag-6
gen experience_man = avgage-edu_man-6
gen experience_nmna = avgage-edu_nmna-6

drop hcpw
gen hcpw = exp(0.1*edu_agg+0.0495*experience-0.0007*(experience^2))
gen hcpw_ag = exp(0.1*edu_ag+0.0495*experience_ag-0.0007*(experience_ag^2))
gen hcpw_man = exp(0.1*edu_man+0.0495*experience_man-0.0007*(experience_man^2))
gen hcpw_nmna = exp(0.1*edu_nmna+0.0495*experience_nmna-0.0007*(experience_nmna^2))

drop tfp
gen tfp = (ypw_agg/(kpw^`alpha'*hcpw^(1-`alpha')))
gen tfp_ag = (ypw_ag/(kpw_ag^(`alpha') *hcpw_ag^(1-`alpha')))
gen tfp_man = (ypw_man/(kpw_man^(`alpha') *hcpw_man^(1-`alpha')))
gen tfp_nmna = (ypw_nmna/(kpw_nmna^(`alpha') *hcpw_nmna^(1-`alpha')))
gen ky = kpw/ypw_agg
gen ky_ag = kpw_ag/ypw_ag
gen ky_man = kpw_man/ypw_man
gen ky_nmna = kpw_nmna/ypw_nmna

// Interpolation of services physical capital for 1840

gen lkpw_nmna = ln(kpw_nmna)
by state (year): replace lkpw_nmna = (L10.lkpw_nmna + F10.lkpw_nmna)/2 if year==1840 & first_decade<=1840
replace kpw_nmna = exp(lkpw_nmna) if year==1840 & first_decade<=1840
replace kpw_nmna = . if year==1840 & first_decade==1840
drop lkpw_nmna

label variable avgage "Average age of workers"

label variable ypw_agg "Output per worker (aggregate)"
label variable ypw_ag "Output per worker (agriculture)"
label variable ypw_man "Output per worker (industrial)"
label variable ypw_nmna "Output per worker (services)"

label variable s_lf_agg "Labor force share (aggregate)"
label variable s_lf_ag "Labor force share (agriculture)"
label variable s_lf_man "Labor force share (industrial)"
label variable s_lf_nmna "Labor force share (services)"

label variable edu_agg "Schooling years per worker (aggregate)"
label variable edu_ag "Schooling years per worker (agriculture)"
label variable edu_man "Schooling per worker (industrial)"
label variable edu_nmna "Schooling per worker (services)"

label variable experience "Experience years per worker (aggregate)"
label variable experience_ag "Experience years per worker (agriculture)"
label variable experience_man "Experience years per worker (industrial)"
label variable experience_nmna "Experience years per worker (services)"

label variable hcpw "Human capital per worker (aggregate)"
label variable hcpw_ag "Human capital per worker (agriculture)"
label variable hcpw_man "Human capital per worker (industrial)"
label variable hcpw_nmna "Human capital per worker (services)"

label variable kpw "Physical capital per worker (aggregate)"
label variable kpw_ag "Physical capital per worker (agriculture)"
label variable kpw_man "Physical capital per worker (industrial)"
label variable kpw_nmna "Physical capital per worker (services)"

label variable tfp "Total factor productivity (aggregate)"
label variable tfp_ag "Total factor productivity (agriculture)"
label variable tfp_man "Total factor productivity (industrial)"
label variable tfp_nmna "Total factor productivity (services)"

label variable ky "Capital-output ratio (aggregate)"
label variable ky_ag "Capital-output ratio (agriculture)"
label variable ky_man "Capital-output ratio (industrial)"
label variable ky_nmna "Capital-output ratio (services)"

 gen macro_div=0
 replace macro_div = 1 if census_div=="Pacific" | census_div=="Mountain"
 replace macro_div = 2 if census_div=="East North Central" | census_div=="Mid Atlantic" | census_div=="New England" | census_div=="West North Central"
 replace macro_div = 3 if census_div=="West South Central" | census_div=="East South Central" | census_div=="South Atlantic"
 label define macro_label 1 "West" 2 "North" 3 "South"
 label values macro_div macro_label

 // Dropping old variables so that this will still execute on my Stata
 
save UseDataFullVariables.dta, replace

keep stateabv state statealp statehood_year id census_div macro_div ypw_agg ypw_ag ypw_man ypw_nmna lf_agg lf_ag lf_man lf_nmna s_lf_agg s_lf_ag s_lf_man s_lf_nmna decade first_decade is_first_decade appears year avgage cen_div_num edu_agg edu_ag edu_man edu_nmna experience experience_ag experience_man experience_nmna hcpw hcpw_ag hcpw_man hcpw_nmna tfp tfp_ag tfp_man tfp_nmna ky ky_ag ky_man ky_nmna kpw kpw_ag kpw_man kpw_nmna

forvalues j = 1800(10)2020 {
	gen in_`j'=0
	label variable in_`j' "Present in `j'"
	replace in_`j'=1 if first_decade<=`j'
}

bysort year: egen num_states_in_year = count(ypw_agg) if ypw_agg!=.

 // Generation of data at the census divisional level
 
bysort census_div year: egen total_work_agg = total(lf_agg)
bysort census_div year: egen total_work_ag = total(lf_ag)
bysort census_div year: egen total_work_man = total(lf_man)
bysort census_div year: egen total_work_nmna = total(lf_nmna)
bysort macro_div year: egen macro_work_agg = total(lf_agg)
bysort macro_div year: egen macro_work_ag = total(lf_ag)
bysort macro_div year: egen macro_work_man = total(lf_man)
bysort macro_div year: egen macro_work_nmna = total(lf_nmna)

gen output_agg=lf_agg*ypw_agg
gen output_ag=lf_ag*ypw_ag
gen output_man=lf_man*ypw_man
gen output_nmna=lf_nmna*ypw_nmna
bysort census_div year: egen total_output_agg = total(output_agg)
bysort census_div year: egen total_output_ag = total(output_ag)
bysort census_div year: egen total_output_man = total(output_man)
bysort census_div year: egen total_output_nmna = total(output_nmna)
bysort macro_div year: egen macro_output_agg = total(output_agg)
bysort macro_div year: egen macro_output_ag = total(output_ag)
bysort macro_div year: egen macro_output_man = total(output_man)
bysort macro_div year: egen macro_output_nmna = total(output_nmna)

gen phys_kapital=lf_agg*kpw
gen phys_ag_kapital=lf_ag*kpw_ag
gen phys_man_kapital=lf_man*kpw_man
gen phys_nmna_kapital=lf_nmna*kpw_nmna
bysort census_div year: egen total_phys_kapital = total(phys_kapital)
bysort census_div year: egen total_phys_ag_kapital = total(phys_ag_kapital)
bysort census_div year: egen total_phys_man_kapital = total(phys_man_kapital)
bysort census_div year: egen total_phys_nmna_kapital = total(phys_nmna_kapital)
bysort macro_div year: egen macro_phys_kapital = total(phys_kapital)
bysort macro_div year: egen macro_phys_ag_kapital = total(phys_ag_kapital)
bysort macro_div year: egen macro_phys_man_kapital = total(phys_man_kapital)
bysort macro_div year: egen macro_phys_nmna_kapital = total(phys_nmna_kapital)

gen hum_kapital =lf_agg*hcpw
gen hum_ag_kapital =lf_ag*hcpw_ag
gen hum_man_kapital =lf_man*hcpw_man
gen hum_nmna_kapital =lf_nmna*hcpw_nmna
bysort census_div year: egen total_hum_kapital = total(hum_kapital)
bysort census_div year: egen total_hum_ag_kapital = total(hum_ag_kapital)
bysort census_div year: egen total_hum_man_kapital = total(hum_man_kapital)
bysort census_div year: egen total_hum_nmna_kapital = total(hum_nmna_kapital)
bysort macro_div year: egen macro_hum_kapital = total(hum_kapital)
bysort macro_div year: egen macro_hum_ag_kapital = total(hum_ag_kapital)
bysort macro_div year: egen macro_hum_man_kapital = total(hum_man_kapital)
bysort macro_div year: egen macro_hum_nmna_kapital = total(hum_nmna_kapital)

gen years_schooling = lf_agg*edu_agg 
gen years_ag_schooling = lf_ag*edu_ag
gen years_man_schooling = lf_man*edu_man 
gen years_nmna_schooling = lf_nmna*edu_nmna
bysort census_div year: egen total_edu_agg = total(years_schooling)
bysort census_div year: egen total_edu_ag = total(years_ag_schooling)
bysort census_div year: egen total_edu_man = total(years_man_schooling)
bysort census_div year: egen total_edu_nmna = total(years_nmna_schooling)
bysort macro_div year: egen macro_edu_agg = total(years_schooling)
bysort macro_div year: egen macro_edu_ag = total(years_ag_schooling)
bysort macro_div year: egen macro_edu_man = total(years_man_schooling)
bysort macro_div year: egen macro_edu_nmna = total(years_nmna_schooling)

gen years_experience = lf_agg*experience
gen years_ag_experience = lf_ag*experience_ag
gen years_man_experience = lf_man*experience_man
gen years_nmna_experience = lf_nmna*experience_nmna
bysort census_div year: egen total_experience_agg = total(years_experience)
bysort census_div year: egen total_experience_ag = total(years_ag_experience)
bysort census_div year: egen total_experience_man = total(years_man_experience)
bysort census_div year: egen total_experience_nmna = total(years_nmna_experience)
bysort macro_div year: egen macro_experience_agg = total(years_experience)
bysort macro_div year: egen macro_experience_ag = total(years_ag_experience)
bysort macro_div year: egen macro_experience_man = total(years_man_experience)
bysort macro_div year: egen macro_experience_nmna = total(years_nmna_experience)

gen years_age = lf_agg*avgage
bysort census_div year: egen total_years_age = total(years_age)
bysort macro_div year: egen macro_years_age = total(years_age)

 foreach x of varlist kpw kpw_ag kpw_man kpw_nmna ky ky_ag ky_man ky_nmna hcpw hcpw_ag hcpw_man hcpw_nmna avgage{
	bysort census_div year: egen total_`x' = total(`x')
 }

gen ypw_agg_census = total_output_agg / total_work_agg
gen ypw_ag_census = total_output_ag / total_work_ag
gen ypw_man_census = total_output_man / total_work_man
gen ypw_nmna_census = total_output_nmna / total_work_nmna
gen ypw_agg_macro = macro_output_agg / macro_work_agg
gen ypw_ag_macro = macro_output_ag / macro_work_ag
gen ypw_man_macro = macro_output_man / macro_work_man
gen ypw_nmna_macro = macro_output_nmna / macro_work_nmna

gen kpw_census = total_phys_kapital / total_work_agg
gen kpw_ag_census = total_phys_ag_kapital / total_work_ag
gen kpw_man_census = total_phys_man_kapital / total_work_man
gen kpw_nmna_census = total_phys_nmna_kapital / total_work_nmna
gen kpw_macro = macro_phys_kapital / macro_work_agg
gen kpw_ag_macro = macro_phys_ag_kapital / macro_work_ag
gen kpw_man_macro = macro_phys_man_kapital / macro_work_man
gen kpw_nmna_macro = macro_phys_nmna_kapital / macro_work_nmna

gen hcpw_census = total_hum_kapital / total_work_agg
gen hcpw_ag_census = total_hum_ag_kapital / total_work_ag
gen hcpw_man_census = total_hum_man_kapital / total_work_man
gen hcpw_nmna_census = total_hum_nmna_kapital / total_work_nmna
gen hcpw_macro = macro_hum_kapital / macro_work_agg
gen hcpw_ag_macro = macro_hum_ag_kapital / macro_work_ag
gen hcpw_man_macro = macro_hum_man_kapital / macro_work_man
gen hcpw_nmna_macro = macro_hum_nmna_kapital / macro_work_nmna

gen ky_census = total_phys_kapital / ypw_agg_census
gen ky_ag_census = total_phys_ag_kapital / ypw_ag_census
gen ky_man_census = total_phys_man_kapital / ypw_man_census
gen ky_nmna_census = total_phys_nmna_kapital / ypw_nmna_census
gen ky_macro = macro_phys_kapital / ypw_agg_macro
gen ky_ag_macro = macro_phys_ag_kapital / ypw_ag_macro
gen ky_man_macro = macro_phys_man_kapital / ypw_man_macro
gen ky_nmna_macro = macro_phys_nmna_kapital / ypw_nmna_macro

gen tfp_census = ypw_agg_census / ((kpw_census^0.33)*(hcpw_census^0.67))
gen tfp_ag_census = ypw_ag_census / ((kpw_ag_census^0.33)*(hcpw_ag_census^0.67))
gen tfp_man_census = ypw_man_census / ((kpw_man_census^0.33)*(hcpw_man_census^0.67))
gen tfp_nmna_census = ypw_nmna_census / ((kpw_nmna_census^0.33)*(hcpw_nmna_census^0.67))
gen tfp_macro = ypw_agg_macro / ((kpw_macro^0.33)*(hcpw_macro^0.67))
gen tfp_ag_macro = ypw_ag_macro / ((kpw_ag_macro^0.33)*(hcpw_ag_macro^0.67))
gen tfp_man_macro = ypw_man_macro / ((kpw_man_macro^0.33)*(hcpw_man_macro^0.67))
gen tfp_nmna_macro = ypw_nmna_macro / ((kpw_nmna_macro^0.33)*(hcpw_nmna_macro^0.67))

gen edu_agg_census = total_edu_agg / total_work_agg
gen edu_ag_census = total_edu_ag / total_work_ag
gen edu_man_census = total_edu_man / total_work_man
gen edu_nmna_census = total_edu_nmna / total_work_nmna
gen edu_agg_macro = macro_edu_agg / macro_work_agg
gen edu_ag_macro = macro_edu_ag / macro_work_ag
gen edu_man_macro = macro_edu_man / macro_work_man
gen edu_nmna_macro = macro_edu_nmna / macro_work_nmna

gen work_agg_census = total_experience_agg / total_work_agg
gen work_ag_census = total_experience_ag / total_work_ag
gen work_man_census = total_experience_man / total_work_man
gen work_nmna_census = total_experience_nmna / total_work_nmna
gen work_agg_macro = macro_experience_agg / macro_work_agg
gen work_ag_macro = macro_experience_ag / macro_work_ag
gen work_man_macro = macro_experience_man / macro_work_man
gen work_nmna_macro = macro_experience_nmna / macro_work_nmna

gen avgage_census = total_years_age / total_work_agg
gen avgage_macro = macro_years_age / macro_work_agg

gen s_lf_ag_census = total_work_ag/total_work_agg
gen s_lf_man_census = total_work_man/total_work_agg
gen s_lf_nmna_census = total_work_nmna/total_work_nmna

foreach x of varlist s_lf_ag s_lf_man s_lf_nmna {
    local mylabel: variable label `x'
	label variable `x'_census "`mylabel'"
}

sort state year
xtset state year

foreach i of varlist ypw_agg ypw_ag ypw_man ypw_nmna lf_agg lf_ag lf_man lf_nmna {
	sort year state
	gen qtile_`i'=.
forvalues j = 1810(10)2020 {
	xtile qtile_`i'_`j' = `i' if year==`j', n(4)
	replace qtile_`i' = qtile_`i'_`j' if year==`j'
}
	bysort year: egen rank_`i' = rank(-`i')	
	gen percentile_`i' = ((rank_`i'-1)/(num_states_in_year - 1))*100
}

foreach x of varlist lf_ag lf_man lf_nmna {
    gen tiny_`x'=0
	replace tiny_`x'=1 if `x'<1000 & s_`x'<0.005	
}

foreach i of varlist ypw_agg ypw_ag ypw_man ypw_nmna{
	sort state year
	xtset state year
    gen change_percentile_`i' = percentile_`i' - L10.percentile_`i'
	replace change_percentile_`i'=. if year==first_decade
	gen abs_change_percentile_`i' = abs(change_percentile_`i')
	replace abs_change_percentile_`i'=. if year==first_decade
}

// This section I programmed up quickly just to run once. It will break your code if you run it twice in a row. I've commented it out.

file open myfile_agg using "mobility_results_ypw_agg.txt", write replace
file write myfile_agg "Variable" _tab "Period" _tab "Mean_Abs_Percentile_Change" _n
forvalues j = 1810(10)2020 {
	summarize abs_change_percentile_ypw_agg if year==`j'
    file write myfile_agg "ypw_agg" _tab "`j'" _tab (r(mean)) _n
}
file close myfile_agg

file open myfile_ag using "mobility_results_ypw_ag.txt", write replace
file write myfile_ag "Variable" _tab "Period" _tab "Mean_Abs_Percentile_Change" _n
forvalues j = 1810(10)2020 {
	summarize abs_change_percentile_ypw_ag if year==`j'
    file write myfile_ag "ypw_ag" _tab "`j'" _tab (r(mean)) _n
}
file close myfile_ag

file open myfile_man using "mobility_results_ypw_man.txt", write replace
file write myfile_man "Variable" _tab "Period" _tab "Mean_Abs_Percentile_Change" _n
forvalues j = 1810(10)2020 {
	summarize abs_change_percentile_ypw_man if year==`j'
    file write myfile_man "ypw_man" _tab "`j'" _tab (r(mean)) _n
}
file close myfile_man

file open myfile_nmna using "mobility_results_ypw_nmna.txt", write replace
file write myfile_nmna "Variable" _tab "Period" _tab "Mean_Abs_Percentile_Change" _n
forvalues j = 1810(10)2020 {
	summarize abs_change_percentile_ypw_nmna if year==`j'
    file write myfile_nmna "ypw_nmna" _tab "`j'" _tab (r(mean)) _n
}
file close myfile_nmna

save UseData.dta, replace

cd "$path_data"