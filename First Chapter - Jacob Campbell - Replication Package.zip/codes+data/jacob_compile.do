
/*
================================================================================
REPLICATION PACKAGE ZIPPER
================================================================================
This script creates a complete, ready-to-use replication package with proper
folder structure. The resulting package can be zipped and distributed.

Output: A /zipper folder with everything organized and ready to run.
================================================================================
*/


******************************************
** Jacob: Setting paths, calling data **
******************************************

do "jacob_pathfinder.do"

// Also create locals for backward compatibility
local path "$path"
local path_data "$path_data"
local path_figs "$path_figs"
local path_legacy "$path_legacy"
local path_literature "$path_literature"
local path_log "$path_log"
local path_tabs "$path_tabs"
local path_zipper "$path_zipper"

di as result "Creating replication package in: $path_zipper"


******************************************
** Compile LaTeX document **
******************************************

di as result "Compiling LaTeX document..."

// Change to tables directory where the .tex file lives
cd "`path_tabs'"

// Run pdflatex twice (first for content, second for references/citations)
! "$comp/pdflatex.exe" -interaction=nonstopmode FirstChapter.ltx
! "$comp/pdflatex.exe" -interaction=nonstopmode FirstChapter.ltx

// Clean up auxiliary files (optional)
! del FirstChapter.aux
! del FirstChapter.log
! del FirstChapter.out

copy "$path_tabs/FirstChapter.pdf" "`path'/FirstChapter.pdf", replace

cd "$path_data"
