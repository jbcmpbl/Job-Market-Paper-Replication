capture program drop estgrab
program define estgrab
    version 16.1
    // Usage:
    //   estgrab m1 m2 ..., save("out.dta") [keep(pattern)] [drop(pattern)] [keep_year]
    //
    // Notes:
    //   - m1 m2 ... are names used with "estimates store"
    //   - keep(pattern): keep only terms whose names contain pattern
    //   - drop(pattern): drop terms whose names contain pattern
    //   - without keep_year, factor terms containing ".year" are skipped

    syntax namelist, SAVE(string) [KEEP(string) DROP(string) KEEp_year]

    tempname H B V
    postfile `H' str64 model str120 term ///
        double b se t p ///
        byte star_10 byte star_05 byte star_01 byte star_001 ///
        str4 stars using "`save'", replace

    foreach M of local namelist {
        quietly estimates restore `M'
        matrix `B' = e(b)
        matrix `V' = e(V)
        local df = e(df_r)

        local cols : colnames `B'
        foreach term of local cols {
            // auto-skip year FE unless keep_year is specified
            if ("`keep_year'"=="") & strpos("`term'",".year")>0 continue

            // optional keep/drop filters
            if `"`keep'"' != "" {
                if strpos("`term'","`keep'")==0 continue
            }
            if `"`drop'"' != "" {
                if strpos("`term'","`drop'")>0 continue
            }

            // pull b, se from e(b) and e(V)
            local j = colnumb(`B', "`term'")
            if missing(`j') continue
            scalar b  = `B'[1, `j']
            scalar se = sqrt(`V'[`j', `j'])
            if missing(b) | se==0 continue

            // test statistic and p-value
            scalar t = b/se
            scalar p = .
            if missing(`df') scalar p = 2*normal(-abs(t))
            else             scalar p = 2*ttail(`df', abs(t))

            // significance flags and star string
            scalar s001 = (p<0.001)
            scalar s01  = (p<0.01)
            scalar s05  = (p<0.05)
            scalar s10  = (p<0.10)
            local stars ""
			if		s001 local stars "***"
            else if s01 local stars "***"
            else if s05  local stars "**"
            else if s10  local stars "*"

            post `H' ("`M'") ("`term'") (b) (se) (t) (p) ///
                (s10) (s05) (s01) (s001) ("`stars'")
        }
    }
    postclose `H'
end

	








******************************************
** Jacob: Setting paths, calling data **
******************************************

do "jacob_pathfinder.do"

// Also create locals for backward compatibility
local path "$path"
local path_data "$path_data"
local path_figs "$path_figs"
local path_legacy "$path_legacy"
local path_literature "$path_literature"
local path_log "$path_log"
local path_tabs "$path_tabs"
local path_zipper "$path_zipper"

	use UseData.dta, clear
	save UseDataConvergence.dta, replace
	use UseDataConvergence.dta, clear
	
*****************************

// Jacob (8/11/25): Temporary, not ideal for time series charts
xtset state year 

// keep if decade==year

foreach x of varlist ypw_agg ypw_ag ypw_man ypw_nmna hcpw hcpw_ag hcpw_man hcpw_nmna kpw kpw_ag kpw_man kpw_nmna ky ky_ag ky_man ky_nmna tfp tfp_ag tfp_man tfp_nmna s_lf_ag s_lf_man s_lf_nmna {

local mylabel: variable label `x'

gen l`x'=log(`x')

gen gl`x'_ann = (l`x'-L.l`x')
gen l`x'0_ann = (L.l`x')

gen l`x'0= L10.l`x' 
label variable l`x'0 "Initial `mylabel' (decadal)"
gen gl`x' = (l`x'-L10.l`x')/10
label variable gl`x' "Growth of `mylabel' (decadal)"

forvalues y = 10(10)220 {
	gen gl`x'_Y`y' = (l`x'-L`y'.l`x')/`y'
	gen l`x'0_Y`y'= L`y'.l`x'
	
}

gen gl`x'_LR = 1
label variable gl`x'_LR "Growth of `mylabel' (long-run)"
gen l`x'_LR = 1
label variable l`x'_LR "Initial `mylabel' (long-run)"
 }

save "UseDataConvergence.dta", replace
clear
use UseDataConvergence, clear

**********************************************
**********************************************
*************** Convergence Regressions ******
**********************************************
**********************************************

***************************
***************************
// ALTERNATE PERIODIZATIONS
***************************
***************************

// REGRESSIONS ON 1800-1850, 1850-1910, 1910-1960, 1960-2020

foreach x of varlist ypw_agg ypw_ag ypw_man ypw_nmna /* hcpw hcpw_ag hcpw_man hcpw_nmna kpw kpw_ag kpw_man kpw_nmna ky ky_ag ky_man ky_nmna tfp tfp_ag tfp_man tfp_nmna s_lf_ag s_lf_man s_lf_nmna */ {

reg gl`x' l`x'0 i.year  if decade==year & year<=1850 & year>1800 , cl(id)
estimates store QuarterA

reg gl`x' l`x'0 i.year  if decade==year & year<=1910 & year>1850 , cl(id)
estimates store QuarterB

reg gl`x' l`x'0 i.year  if decade==year & year<=1960 & year>1900 , cl(id)
estimates store QuarterC

reg gl`x' l`x'0 i.year  if decade==year & year<=2020 & year>1960 , cl(id)
estimates store QuarterD

esttab QuarterA QuarterB QuarterC QuarterD using "`path_tabs'/conv_table_four_period_`x'.tex", replace b(4) se(4) r2(2) label mtitles("1800-1850" "1850-1910" "1910-1960" "1960-2020") nonumbers drop(*.year _cons) addnote("Notes: ") nobaselevels alignment(c) star(* 0.10 ** 0.05 *** 0.01) ///

}

clear
use UseDataConvergence, clear

// REGRESSIONS ON 1800-1910, 1910-2020 AND 1800-2020

foreach x of varlist ypw_agg ypw_ag ypw_man ypw_nmna /* hcpw hcpw_ag hcpw_man hcpw_nmna kpw kpw_ag kpw_man kpw_nmna ky ky_ag ky_man ky_nmna tfp tfp_ag tfp_man tfp_nmna s_lf_ag s_lf_man s_lf_nmna */ {

// Unbalanced version
reg gl`x' l`x'0 i.year  if decade==year & year<=1910 & year>1800 , cl(id)
estimates store MoietyA

reg gl`x' l`x'0 i.year  if decade==year & year<=2020 & year>=1910 , cl(id)
estimates store MoietyB

replace gl`x'_LR = gl`x'_Y110
replace l`x'_LR = l`x'0_Y110
reg gl`x'_LR l`x'_LR if decade==year & year==1910
estimates store MoietyA_LR
reg gl`x'_LR l`x'_LR if decade==year & year==2020
estimates store MoietyB_LR

reg gl`x' l`x'0 i.year  if decade==year & year<=2020 & year>1800 , cl(id)
estimates store FullPeriod 
replace gl`x'_LR = gl`x'_Y220
replace l`x'_LR = l`x'0_Y220
reg gl`x'_LR l`x'_LR if decade==year & year==2020
estimates store FullPeriod_LR

// Balanced verison

reg gl`x' l`x'0 i.year  if decade==year & year<=1910 & year>1800 & in_1800==1, cl(id)
estimates store MoietyA_BA

reg gl`x' l`x'0 i.year  if decade==year & year<=2020 & year>=1910 & in_1910==1, cl(id)
estimates store MoietyB_BB

replace gl`x'_LR = gl`x'_Y110
replace l`x'_LR = l`x'0_Y110
reg gl`x'_LR l`x'_LR if decade==year & year==1910 & in_1800==1
estimates store MoietyA_BA_LR
reg gl`x'_LR l`x'_LR if decade==year & year==2020 & in_1910==1
estimates store MoietyB_BB_LR

reg gl`x' l`x'0 i.year  if decade==year & year<=2020 & year>1800 & in_1800==1, cl(id)
estimates store FullPeriod_Balanced
/*
esttab MoietyA MoietyA_BA MoietyA_BA_LR MoietyB MoietyB_BB MoietyB_BB_LR using "`path_tabs'/conv_table_two_period_`x'_balanced.tex", replace b(4) se(4) r2(2) label mtitles("Unbal. panel 1800-1910" "Bal. panel 1880-1910" "Cross-section 1800-1910" "Unbal. panel 1910-2020" "Bal. panel 1910-2020" "Cross-section 1910-2020") nonumbers drop(*.year _cons) addnote("Notes: ") nobaselevels alignment(c) star(* 0.10 ** 0.05 *** 0.01)
*/
esttab MoietyA MoietyA_BA MoietyA_BA_LR MoietyB MoietyB_BB MoietyB_BB_LR using "`path_tabs'/conv_table_two_period_`x'_balanced.tex", replace b(4) se(4) r2(2) label mgroups("1800-1910" "1910-2020", pattern(1 0 0 1 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) mtitles("Unbal. panel" "Bal. panel" "Cross-section" "Unbal. panel" "Bal. panel" "Cross-section") nonumbers drop(*.year _cons) addnote("Notes: ") nobaselevels alignment(c) star(* 0.10 ** 0.05 *** 0.01)

esttab FullPeriod FullPeriod_LR FullPeriod_Balanced using "`path_tabs'/conv_table_one_period_`x'_balanced.tex", replace b(4) se(4) r2(2) label mgroups("1800-2020", pattern(1 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) mtitles("Unbal. panel" "Bal. panel" "Cross-section") nonumbers drop(*.year _cons) addnote("Notes: ") nobaselevels alignment(c) star(* 0.10 ** 0.05 *** 0.01) ///

}

clear
use UseDataConvergence, clear

// MACRO-DIVISIONAL REGRESSIONS

foreach x of varlist ypw_agg ypw_ag ypw_man ypw_nmna /* hcpw hcpw_ag hcpw_man hcpw_nmna kpw kpw_ag kpw_man kpw_nmna ky ky_ag ky_man ky_nmna tfp tfp_ag tfp_man tfp_nmna s_lf_ag s_lf_man s_lf_nmna */ {

// Unbalanced version
reg gl`x' l`x'0 i.year  if decade==year & year<=1910 & year>1800 & macro_div==2, cl(id)
estimates store North_Early_`x'

reg gl`x' l`x'0 i.year  if decade==year & year<=2020 & year>=1910 & macro_div==2, cl(id)
estimates store North_Late_`x'

reg gl`x' l`x'0 i.year  if decade==year & year<=1910 & year>1800 & macro_div==3, cl(id)
estimates store South_Early_`x'

reg gl`x' l`x'0 i.year  if decade==year & year<=2020 & year>=1910 & macro_div==3, cl(id)
estimates store South_Late_`x'

reg gl`x' l`x'0 i.year  if decade==year & year<=1910 & year>1800 & macro_div==1, cl(id)
estimates store West_Early_`x'

reg gl`x' l`x'0 i.year  if decade==year & year<=2020 & year>=1910 & macro_div==1, cl(id)
estimates store West_Late_`x'

esttab North_Early_`x' South_Early_`x' West_Early_`x' North_Late_`x' South_Late_`x' West_Late_`x' using "`path_tabs'/conv_table_three_regions_`x'.tex", replace b(4) se(4) r2(2) label mgroups("1800-1910" "1910-2020", pattern(1 0 0 1 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) mtitles("North" "South" "West" "North" "South" "West") nonumbers drop(*.year _cons) addnote("Notes: ") nobaselevels alignment(c) star(* 0.10 ** 0.05 *** 0.01)

}

clear
use UseDataConvergence, clear

******************
// ROLLING WINDOWS
******************

/*
xtset state year 

foreach x of varlist ypw_agg ypw_ag ypw_man ypw_nmna /* hcpw hcpw_ag hcpw_man hcpw_nmna kpw kpw_ag kpw_man kpw_nmna ky ky_ag ky_man ky_nmna tfp tfp_ag tfp_man tfp_nmna s_lf_ag s_lf_man s_lf_nmna */ {

local mylabel: variable label `x'

gen l`x'=log(`x')

gen gl`x'_ann = (l`x'-L.l`x')
gen l`x'0_ann = (L.l`x')

gen l`x'0= L10.l`x' 
label variable l`x'0 "Initial `mylabel' (decadal)"
gen gl`x' = (l`x'-L10.l`x')/10
label variable gl`x' "Growth of `mylabel' (decadal)"

forvalues y = 10(10)220 {
	gen gl`x'_Y`y' = (l`x'-L`y'.l`x')/`y'
	gen l`x'0_Y`y'= L`y'.l`x'
	
}

gen gl`x'_LR = 1
label variable gl`x'_LR "Growth of `mylabel' (long-run)"
gen l`x'_LR = 1
label variable l`x'_LR "Initial `mylabel' (long-run)"
 }
 
 */

use UseDataConvergence.dta
xtset state year
preserve
postfile hondle_ypw_agg start beta se observations using "roll_result_ypw_agg", replace
forvalues s = 1800(10)2010 {
	local e = `s' + 10
	reg glypw_agg lypw_agg0 if inrange(year,`s'+10,`e') & in_`s'==1
	local b = _b[lypw_agg0]
	local se = _se[lypw_agg0]
	local N = e(N)
	post hondle_ypw_agg (`s') (`b') (`se') (`N')
}
postclose hondle_ypw_agg
restore
use "roll_result_ypw_agg.dta", clear
save "roll_result_ypw_agg.dta", replace
list

use "UseDataConvergence.dta", clear
xtset state year
preserve
postfile hondle_ypw_ag start beta se observations using "roll_result_ypw_ag", replace
forvalues s = 1800(10)2010 {
	local e = `s' + 10
	reg glypw_ag lypw_ag0 if inrange(year,`s'+10,`e') & in_`s'==1
	local b = _b[lypw_ag0]
	local se = _se[lypw_ag0]
	local N = e(N)
	post hondle_ypw_ag (`s') (`b') (`se') (`N')
}
postclose hondle_ypw_ag
restore
use "roll_result_ypw_ag.dta", clear
save "roll_result_ypw_ag.dta", replace
list

use "UseDataConvergence.dta", clear
xtset state year
preserve
postfile hondle_ypw_man start beta se observations using "roll_result_ypw_man", replace
forvalues s = 1800(10)2010 {
	local e = `s' + 10
	reg glypw_man lypw_man0 if inrange(year,`s'+10,`e') & in_`s'==1
	local b = _b[lypw_man0]
	local se = _se[lypw_man0]
	local N = e(N)
	post hondle_ypw_man (`s') (`b') (`se') (`N')
}
postclose hondle_ypw_man
restore
use "roll_result_ypw_man.dta", clear
save "roll_result_ypw_man.dta", replace
list

use "UseDataConvergence.dta", clear
xtset state year
preserve
postfile hondle_ypw_nmna start beta se observations using "roll_result_ypw_nmna", replace
forvalues s = 1800(10)2010 {
	local e = `s' + 10
	reg glypw_nmna lypw_nmna0 if inrange(year,`s'+10,`e') & in_`s'==1
	local b = _b[lypw_nmna0]
	local se = _se[lypw_nmna0]
	local N = e(N)
	post hondle_ypw_nmna (`s') (`b') (`se') (`N')
}
postclose hondle_ypw_nmna
restore
use "roll_result_ypw_nmna.dta", clear
save "roll_result_ypw_nmna.dta", replace
list

use roll_result_ypw_agg, clear
gen sector = "Aggregate"
append using roll_result_ypw_ag
replace sector = "Agriculture" if missing(sector)
append using roll_result_ypw_man
replace sector = "Industry" if missing(sector)
append using roll_result_ypw_nmna
replace sector = "Services" if missing(sector)
save "roll_result.dta", replace

use roll_result, clear
gen upper = beta+2*se
gen lower = beta-2*se

twoway ///
    (rarea upper lower start if sector=="Aggregate", color(gs14)) ///
    (line beta start if sector=="Aggregate", lcolor(blue)) ///
    , yline(0, lpattern(dash) lcolor(red)) ///
      plotregion(fcolor(white)) graphregion(fcolor(white)) ///
      title("Aggregate") name(gagg, replace)

twoway ///
    (rarea upper lower start if sector=="Agriculture", color(gs14)) ///
    (line beta start if sector=="Agriculture", lcolor(blue)) ///
    , yline(0, lpattern(dash) lcolor(red)) ///
      plotregion(fcolor(white)) graphregion(fcolor(white)) ///
      title("Agriculture") name(gag, replace)
	
twoway ///
    (rarea upper lower start if sector=="Industry", color(gs14)) ///
    (line beta start if sector=="Industry", lcolor(blue)) ///
    , yline(0, lpattern(dash) lcolor(red)) ///
      plotregion(fcolor(white)) graphregion(fcolor(white)) ///
      title("Industry") name(gman, replace)

twoway ///
    (rarea upper lower start if sector=="Services", color(gs14)) ///
    (line beta start if sector=="Services", lcolor(blue)) ///
    , yline(0, lpattern(dash) lcolor(red)) ///
      plotregion(fcolor(white)) graphregion(fcolor(white)) ///
      title("Services") name(gnmna, replace)

graph combine gagg gag gman gnmna, iscale(0.5)  col(2) plotregion(fcolor(white)) graphregion(fcolor(white)) xcommon ycommon
graph save "`path_figs'\beta_roll_window.gph", replace
graph export "`path_figs'\beta_roll_window.png", replace

// ROLLING WINDOW REGRESSIONS - 40 YEAR ROLL
use "UseDataConvergence.dta", clear
xtset state year
preserve
postfile hondle_ypw_agg start beta se observations using "roll_result_ypw_agg", replace
forvalues s = 1800(10)1980 {
	local e = `s' + 40
	reg glypw_agg lypw_agg0 i.year if inrange(year,`s'+10,`e') & in_`s'==1, cl(id)
	local b = _b[lypw_agg0]
	local se = _se[lypw_agg0]
	local N = e(N)
	post hondle_ypw_agg (`s') (`b') (`se') (`N')
}
postclose hondle_ypw_agg
restore
use "roll_result_ypw_agg.dta", clear
save "roll_result_ypw_agg.dta", replace
list

use "UseDataConvergence.dta", clear
xtset state year
preserve
postfile hondle_ypw_ag start beta se observations using "roll_result_ypw_ag", replace
forvalues s = 1800(10)1980 {
	local e = `s' + 40
	reg glypw_ag lypw_ag0 i.year if inrange(year,`s'+10,`e') & in_`s'==1, cl(id)
	local b = _b[lypw_ag0]
	local se = _se[lypw_ag0]
	local N = e(N)
	post hondle_ypw_ag (`s') (`b') (`se') (`N')
}
postclose hondle_ypw_ag
restore
use "roll_result_ypw_ag.dta", clear
save "roll_result_ypw_ag.dta", replace
list

use "UseDataConvergence.dta", clear
xtset state year
preserve
postfile hondle_ypw_man start beta se observations using "roll_result_ypw_man", replace
forvalues s = 1800(10)1980 {
	local e = `s' + 40
	reg glypw_man lypw_man0 i.year if inrange(year,`s'+10,`e') & in_`s'==1, cl(id)
	local b = _b[lypw_man0]
	local se = _se[lypw_man0]
	local N = e(N)
	post hondle_ypw_man (`s') (`b') (`se') (`N')
}
postclose hondle_ypw_man
restore
use "roll_result_ypw_man.dta", clear
save "roll_result_ypw_man.dta", replace
list

use "UseDataConvergence.dta", clear
xtset state year
preserve
postfile hondle_ypw_nmna start beta se observations using "roll_result_ypw_nmna", replace
forvalues s = 1800(10)1980 {
	local e = `s' + 40
	reg glypw_nmna lypw_nmna0 i.year if inrange(year,`s'+10,`e') & in_`s'==1, cl(id)
	local b = _b[lypw_nmna0]
	local se = _se[lypw_nmna0]
	local N = e(N)
	post hondle_ypw_nmna (`s') (`b') (`se') (`N')
}
postclose hondle_ypw_nmna
restore
use "roll_result_ypw_nmna.dta", clear
save "roll_result_ypw_nmna.dta", replace
list

use roll_result_ypw_agg, clear
gen sector = "Aggregate"
append using roll_result_ypw_ag
replace sector = "Agriculture" if missing(sector)
append using roll_result_ypw_man
replace sector = "Industry" if missing(sector)
append using roll_result_ypw_nmna
replace sector = "Services" if missing(sector)
save "roll_result.dta", replace

use roll_result, clear
gen upper = beta+2*se
gen lower = beta-2*se

twoway ///
    (rarea upper lower start if sector=="Aggregate", color(gs14)) ///
    (line beta start if sector=="Aggregate", lcolor(blue)) ///
    , yline(0, lpattern(dash) lcolor(red)) ///
      plotregion(fcolor(white)) graphregion(fcolor(white)) ///
      title("Aggregate") name(gagg, replace)

twoway ///
    (rarea upper lower start if sector=="Agriculture", color(gs14)) ///
    (line beta start if sector=="Agriculture", lcolor(blue)) ///
    , yline(0, lpattern(dash) lcolor(red)) ///
      plotregion(fcolor(white)) graphregion(fcolor(white)) ///
      title("Agriculture") name(gag, replace)
	
twoway ///
    (rarea upper lower start if sector=="Industry", color(gs14)) ///
    (line beta start if sector=="Industry", lcolor(blue)) ///
    , yline(0, lpattern(dash) lcolor(red)) ///
      plotregion(fcolor(white)) graphregion(fcolor(white)) ///
      title("Industry") name(gman, replace)

twoway ///
    (rarea upper lower start if sector=="Services", color(gs14)) ///
    (line beta start if sector=="Services", lcolor(blue)) ///
    , yline(0, lpattern(dash) lcolor(red)) ///
      plotregion(fcolor(white)) graphregion(fcolor(white)) ///
      title("Services") name(gnmna, replace)

graph combine gagg gag gman gnmna, iscale(0.5)  col(2) plotregion(fcolor(white)) graphregion(fcolor(white)) xcommon ycommon
graph save "`path_figs'\beta_roll_window_40.gph", replace
graph export "`path_figs'\beta_roll_window_40.png", replace

clear
use UseDataConvergence, clear



// NOTE: THIS SECTION IS MADE REDUNDANT, MOSTLY, BY THE ROLLING WINDOW
// CROSS-SECTIONAL DECADE REGRESSIONS

/*
forvalues y = 1810(10)2020 {
    reg gl`x'_Y10 l`x' if decade==year & year==`y'
	estimates store CrossSection_`y'
	
esttab CrossSection_* using "`path_tabs'/conv_table_cross_sec_`x'.tex", replace b(4) se(4) r2(2) /* label mtitles() */ nonumbers addnote("Notes: ") nobaselevels alignment(c) star(* 0.10 ** 0.05 *** 0.01) nocons ///
*/

// NOTE: PRELIMINARY RESULTS SHOWED EITHER NO CLUB CONVERGENCE OR A MILLION CLUBS (LIKE, 14 CLUBS, 30 STATES...)
// CLUB CONVERGENCE

/*
/*
preserve
keep if year==decade
psecta `x', gen(club_`x') kq(0.2)
keep state year `x' club_`x'
tempfile club_`x'
save club`x', replace
restore

preserve
keep if year==decade & year<=1860
psecta `x', gen(club_`x'_A) kq(0.2)
keep state year `x' club_`x'_A
tempfile club_`x'_A
save club`x'_A, replace
restore

preserve
keep if year==decade & year>1860 & year<=1910
psecta `x', gen(club_`x'_B) kq(0.2)
keep state year `x' club_`x'_B
tempfile club_`x'_B
save club`x'_B, replace
restore

preserve
keep if year==decade & year>1910 & year<=2020
psecta `x', gen(club_`x'_C) kq(0.2)
keep state year `x' club_`x'_C
tempfile club_`x'_C
save club`x'_C, replace
restore
*/
*/

/*
preserve
keep if year==decade
logtreg ypw_agg, kq(0.3)
restore

preserve
keep if year==decade & year<=1860
logtreg ypw_agg, kq(0.3)
restore

preserve
keep if year==decade & year>1860 & year<=1910
logtreg ypw_agg, kq(0.3)
restore

preserve
keep if year==decade & year>1910 & year<=2020
logtreg ypw_agg, kq(0.3)
restore

preserve
keep if year==decade
logtreg ypw_ag, kq(0.3)
restore

preserve
keep if year==decade & year<=1860
logtreg ypw_ag, kq(0.3)
restore

preserve
keep if year==decade & year>1860 & year<=1910
logtreg ypw_ag, kq(0.3)
restore

preserve
keep if year==decade & year>1910 & year<=2020
logtreg ypw_ag, kq(0.3)
restore

preserve
keep if year==decade
logtreg ypw_man, kq(0.3)
restore

preserve
keep if year==decade & year<=1860
logtreg ypw_man, kq(0.3)
restore

preserve
keep if year==decade & year>1860 & year<=1910
logtreg ypw_man, kq(0.3)
restore

preserve
keep if year==decade & year>1910 & year<=2020
logtreg ypw_man, kq(0.3)
restore

preserve
keep if year==decade
logtreg ypw_nmna, kq(0.3)
restore

preserve
keep if year==decade & year<=1860
logtreg ypw_nmna, kq(0.3)
restore

preserve
keep if year==decade & year>1860 & year<=1910
logtreg ypw_nmna, kq(0.3)
restore

preserve
keep if year==decade & year>1910 & year<=2020
logtreg ypw_nmna, kq(0.3)
restore
*/

/*
    // =========================
    // COLLECT MODEL NAMES FOR THIS x
    // =========================
    // List every estimates name you created above for this x:
    local models PeriodA PeriodB PeriodC PeriodA_LR PeriodB_LR PeriodC_LR ///
                 PeriodA_BA PeriodB_BA PeriodC_BA PeriodA_BA_LR PeriodB_BA_LR PeriodC_BA_LR ///
                 PeriodB_BB PeriodC_BB PeriodB_BB_LR PeriodC_BB_LR ///
                 PeriodC_BC PeriodC_BC_LR ///
                 MoietyA MoietyB MoietyA_LR MoietyB_LR ///
                 MoietyA_BA MoietyB_BB MoietyA_BA_LR MoietyB_BB_LR ///
                 FullPanel FullPanel_LR FullPanel_BA FullPanel_BA_LR ///

    // IMPORTANT: only include names that actually exist for your `x`.
    // If some models are conditional, either guard them or keep separate blocks.

    // =========================
    // HARVEST COEFS FOR THIS x
    // =========================
    // Keep only the regressor(s) you care about (e.g., the "beta" on the initial level):
    capture erase "coefstars_`x'.dta"		
		
	estgrab `models', ///
        save("`path_data'/coefstars_`x'.dta") ///
        keep("l`x'0")

    // If you also want the growth beta(s), run a second harvest:
    // estgrab `models', save("`path_tabs'/coefstars_growth_`x'.dta") keep("gl`x'")

    // If you want literally everything except the i.year FE:
    // estgrab `models', save("`path_tabs'/coefstars_all_`x'.dta")
	
*/

/*
* === AFTER your foreach x loop has finished ===

capture erase "`path_data'/coefstars_ALL.dta"

tempfile master
clear
save `master', emptyok

local folder "`path_data'"
local prefix "coefstars_"

* list all harvested files like coefstars_*.dta
local files : dir "`folder'" files "coefstars_*.dta"

foreach f of local files {
    use "`folder'/`f'", clear

    * pull regressand name from filename: coefstars_<<THIS>>.dta
	
    local base = subinstr("`f'", ".dta", "", .)
    local r = substr("`base'", length("`prefix'") + 1, .)
    gen str32 regressand = "`r'"
	
    * append into the growing master
    append using `master'
    save `master', replace
}

*/

cd "$path_data"
