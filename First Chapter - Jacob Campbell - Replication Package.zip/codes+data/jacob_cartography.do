
******************************************
** Jacob: Setting paths, calling data **
******************************************

do "jacob_pathfinder.do"

// Also create locals for backward compatibility
local path "$path"
local path_data "$path_data"
local path_figs "$path_figs"
local path_legacy "$path_legacy"
local path_literature "$path_literature"
local path_log "$path_log"
local path_tabs "$path_tabs"
local path_zipper "$path_zipper"

	use UseData.dta, clear
	save UseDataCartography.dta, replace
	use UseDataCartography.dta, clear
	
*****************************
/*
ssc install spmap, replace
ssc install shp2dta, replace
ssc install mif2dta, replace
*/

cap which colorpalette
if _rc ssc install palettes
cap which HCLcolor
if _rc ssc install colrspace

colorpalette RdYlGn, n(11) reverse nograph
local cols `r(p)'   // list of "R G B" triplets

shp2dta using cb_2018_us_state_20m, database(usdb) coordinates(uscoord) genid(mapid) replace
use UseDataCartography
gen NAME = proper(statealp)
merge m:1 NAME using "usdb.dta", keepusing(mapid)
drop _merge

/*
gen state_power=lf_agg*lf_agg*ypw_agg

spmap state_power_index using uscoord if year==2020 & NAME!="Hawaii" & NAME!="Alaska", id(mapid) clmethod(unique)   fcolor("0 104 55" "26 152 80" "102 189 99" "166 217 106" "217 239 139" ///
           "255 255 191" "254 224 139" "253 174 97" "244 109 67" "215 48 39" "165 0 38") title("First decade of coverage")
*/

spmap first_decade using uscoord if year==2020 & NAME!="Hawaii" & NAME!="Alaska", id(mapid) clmethod(unique)   fcolor("0 104 55" "26 152 80" "102 189 99" "166 217 106" "217 239 139" ///
           "255 255 191" "254 224 139" "253 174 97" "244 109 67" "215 48 39" "165 0 38") title("First decade of coverage")
		 
graph export "`path_figs'\coverage_map.png", replace

/*
foreach j of varlist ypw_agg ypw_ag ypw_man ypw_nmna {
forvalues i = 1800(10)2020 {
preserve
local mylab: variable label `j'
spmap `j' using uscoord if year==`i' & `j'!=0 & `j'!=. & NAME!="Hawaii" & NAME!="Alaska", id(mapid) clmethod(quantile) clnumber(4) fcolor(red orange yellow green) legend(label(2 "Q1 (lowest)") label(3 "Q2") label(4 "Q3") label(5 "Q4 (highest)")) title("Quartiles of `mylab' in `i'")
graph export "`path_figs'\`j'_`i'_quartiles_map.png", replace
restore
}
}
*/

cd "$path_data"