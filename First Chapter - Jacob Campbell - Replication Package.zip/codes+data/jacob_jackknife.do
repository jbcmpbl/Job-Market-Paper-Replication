capture program drop estgrab
program define estgrab
    version 16.1
    // Usage:
    //   estgrab m1 m2 ..., save("out.dta") [keep(pattern)] [drop(pattern)] [keep_year]
    //
    // Notes:
    //   - m1 m2 ... are names used with "estimates store"
    //   - keep(pattern): keep only terms whose names contain pattern
    //   - drop(pattern): drop terms whose names contain pattern
    //   - without keep_year, factor terms containing ".year" are skipped

    syntax namelist, SAVE(string) [KEEP(string) DROP(string) KEEp_year]

    tempname H B V
    postfile `H' str64 model str120 term ///
        double b se t p ///
        byte star_10 byte star_05 byte star_01 byte star_001 ///
        str4 stars using "`save'", replace

    foreach M of local namelist {
        quietly estimates restore `M'
        matrix `B' = e(b)
        matrix `V' = e(V)
        local df = e(df_r)

        local cols : colnames `B'
        foreach term of local cols {
            // auto-skip year FE unless keep_year is specified
            if ("`keep_year'"=="") & strpos("`term'",".year")>0 continue

            // optional keep/drop filters
            if `"`keep'"' != "" {
                if strpos("`term'","`keep'")==0 continue
            }
            if `"`drop'"' != "" {
                if strpos("`term'","`drop'")>0 continue
            }

            // pull b, se from e(b) and e(V)
            local j = colnumb(`B', "`term'")
            if missing(`j') continue
            scalar b  = `B'[1, `j']
            scalar se = sqrt(`V'[`j', `j'])
            if missing(b) | se==0 continue

            // test statistic and p-value
            scalar t = b/se
            scalar p = .
            if missing(`df') scalar p = 2*normal(-abs(t))
            else             scalar p = 2*ttail(`df', abs(t))

            // significance flags and star string
            scalar s001 = (p<0.001)
            scalar s01  = (p<0.01)
            scalar s05  = (p<0.05)
            scalar s10  = (p<0.10)
            local stars ""
			if		s001 local stars "***"
            else if s01 local stars "***"
            else if s05  local stars "**"
            else if s10  local stars "*"

            post `H' ("`M'") ("`term'") (b) (se) (t) (p) ///
                (s10) (s05) (s01) (s001) ("`stars'")
        }
    }
    postclose `H'
end

	








******************************************
** Jacob: Setting paths, calling data **
******************************************

do "jacob_pathfinder.do"

// Also create locals for backward compatibility
local path "$path"
local path_data "$path_data"
local path_figs "$path_figs"
local path_legacy "$path_legacy"
local path_literature "$path_literature"
local path_log "$path_log"
local path_tabs "$path_tabs"
local path_zipper "$path_zipper"

	use UseData.dta, clear
	save UseDataConvergence.dta, replace
	use UseDataConvergence.dta, clear
	
*****************************

// Jacob (8/11/25): Temporary, not ideal for time series charts
xtset state year 

// keep if decade==year

foreach x of varlist ypw_agg ypw_ag ypw_man ypw_nmna hcpw hcpw_ag hcpw_man hcpw_nmna kpw kpw_ag kpw_man kpw_nmna ky ky_ag ky_man ky_nmna tfp tfp_ag tfp_man tfp_nmna s_lf_ag s_lf_man s_lf_nmna {

local mylabel: variable label `x'

gen l`x'=log(`x')

gen gl`x'_ann = (l`x'-L.l`x')
gen l`x'0_ann = (L.l`x')

gen l`x'0= L10.l`x' 
label variable l`x'0 "Initial `mylabel' (decadal)"
gen gl`x' = (l`x'-L10.l`x')/10
label variable gl`x' "Growth of `mylabel' (decadal)"

forvalues y = 10(10)220 {
	gen gl`x'_Y`y' = (l`x'-L`y'.l`x')/`y'
	gen l`x'0_Y`y'= L`y'.l`x'
	
}

gen gl`x'_LR = 1
label variable gl`x'_LR "Growth of `mylabel' (long-run)"
gen l`x'_LR = 1
label variable l`x'_LR "Initial `mylabel' (long-run)"
 }

save "UseDataConvergence.dta", replace
clear
use UseDataConvergence, clear

*************
// JACK KNIFE
*************

use UseDataConvergence.dta, clear
xtset state year
keep if year==decade

display "JACK KNIVES FOR STATES"
jackknife, cluster(state): reg glypw_agg lypw_agg0 i.year if year<=1910 & year>1800
jackknife, cluster(state): reg glypw_agg lypw_agg0 i.year if year<=2020 & year>1910
jackknife, cluster(state): reg glypw_ag lypw_ag0 i.year if year<=1910 & year>1800
jackknife, cluster(state): reg glypw_ag lypw_ag0 i.year if year<=2020 & year>1910
jackknife, cluster(state): reg glypw_man lypw_man0 i.year if year<=1910 & year>1800
jackknife, cluster(state): reg glypw_man lypw_man0 i.year if year<=2020 & year>1910
jackknife, cluster(state): reg glypw_nmna lypw_nmna0 i.year if year<=1910 & year>1800
jackknife, cluster(state): reg glypw_nmna lypw_nmna0 i.year if year<=2020 & year>1910

display "JACK KNIFES FOR CENSUS DIVISIONS"
jackknife, cluster(census_div): reg glypw_agg lypw_agg0 i.year if year<=1910 & year>1800
jackknife, cluster(census_div): reg glypw_agg lypw_agg0 i.year if year<=2020 & year>1910
jackknife, cluster(census_div): reg glypw_ag lypw_ag0 i.year if year<=1910 & year>1800
jackknife, cluster(census_div): reg glypw_ag lypw_ag0 i.year if year<=2020 & year>1910
jackknife, cluster(census_div): reg glypw_man lypw_man0 i.year if year<=1910 & year>1800
jackknife, cluster(census_div): reg glypw_man lypw_man0 i.year if year<=2020 & year>1910
jackknife, cluster(census_div): reg glypw_nmna lypw_nmna0 i.year if year<=1910 & year>1800
jackknife, cluster(census_div): reg glypw_nmna lypw_nmna0 i.year if year<=2020 & year>1910

gen statealpjack = statealp
replace statealpjack = "northcarolina" if statealp=="north carolina"
replace statealpjack = "southcarolina" if statealp=="south carolina"
replace statealpjack = "northdakota" if statealp=="north dakota"
replace statealpjack = "southdakota" if statealp=="south dakota"
replace statealpjack = "newmexico" if statealp=="new mexico"
replace statealpjack = "newjersey" if statealp=="new jersey"
replace statealpjack = "newyork" if statealp=="new york"
replace statealpjack = "newhampshire" if statealp=="new hampshire"
replace statealpjack = "rhodeisland" if statealp=="rhode island"
replace statealpjack = "westvirginia" if statealp=="west virginia"

gen cendivjack = census_div
replace cendivjack = "eastnorthcentral" if census_div=="East North Central"
replace cendivjack = "eastsouthcentral" if census_div=="East South Central"
replace cendivjack = "midatlantic" if census_div=="Mid Atlantic"
replace cendivjack = "newengland" if census_div=="New England"
replace cendivjack = "southatlantic" if census_div=="South Atlantic"
replace cendivjack = "westnorthcentral" if census_div=="West North Central"
replace cendivjack = "westsouthcentral" if census_div=="West South Central"
replace cendivjack = "mountain" if census_div=="Mountain"
replace cendivjack = "pacific" if census_div=="Pacific"

save "UseDataConvergence.dta", replace

// JACK KNIVES AT THE STATE LEVEL

use UseDataConvergence.dta, clear
xtset state year 
preserve
drop decade
tempfile jacktmp
save `jacktmp', emptyok replace

levelsof state, local(states)

foreach s of local states {

quietly levelsof statealpjack if state==`s', local(statename)

reg glypw_agg lypw_agg0 i.year  if year<=1910 & year>1800 & state!=`s', cl(id)

local b_early = _b[lypw_agg0]
local se_early = _se[lypw_agg0]
local N_early = e(N)

reg glypw_agg lypw_agg0 i.year  if year<=2020 & year>=1910 & state!=`s', cl(id)
local b_late = _b[lypw_agg0]
local se_late = _se[lypw_agg0]
local N_late = e(N)

reg glypw_agg lypw_agg0 i.year  if year<=1910 & year>1800, cl(id)

local b_early_full = _b[lypw_agg0]
local se_early_full = _se[lypw_agg0]
local N_early_full = e(N)

reg glypw_agg lypw_agg0 i.year  if year<=2020 & year>=1910, cl(id)
local b_late_full = _b[lypw_agg0]
local se_late_full = _se[lypw_agg0]
local N_late_full = e(N)

clear
set obs 1
gen str10 statename = `statename'
gen b_early = `b_early'
gen se_early = `se_early'
gen N_early = `N_early'
gen b_late = `b_late'
gen se_late = `se_late'
gen N_late = `N_late'

gen b_early_full = `b_early_full'
gen se_early_full = `se_early_full'
gen N_early_full = `N_early_full'
gen b_late_full = `b_late_full'
gen se_late_full = `se_late_full'
gen N_late_full = `N_late_full'

append using `jacktmp'
save `jacktmp', replace
}

restore
use `jacktmp', clear
drop if b_early==.
save "jack_knife_ypw_agg.dta", replace


use UseDataConvergence.dta, clear
xtset state year 
preserve
drop decade
tempfile jacktmp
save `jacktmp', emptyok replace
levelsof state, local(states)

foreach s of local states {

quietly levelsof statealpjack if state==`s', local(statename)

reg glypw_ag lypw_ag0 i.year  if year<=1910 & year>1800 & state!=`s', cl(id)

local b_early = _b[lypw_ag0]
local se_early = _se[lypw_ag0]
local N_early = e(N)

reg glypw_ag lypw_ag0 i.year  if year<=2020 & year>=1910 & state!=`s', cl(id)
local b_late = _b[lypw_ag0]
local se_late = _se[lypw_ag0]
local N_late = e(N)

reg glypw_agg lypw_agg0 i.year  if year<=1910 & year>1800, cl(id)

local b_early_full = _b[lypw_agg0]
local se_early_full = _se[lypw_agg0]
local N_early_full = e(N)

reg glypw_agg lypw_agg0 i.year  if year<=2020 & year>=1910, cl(id)
local b_late_full = _b[lypw_agg0]
local se_late_full = _se[lypw_agg0]
local N_late_full = e(N)

clear
set obs 1
gen str10 statename = `statename'
gen b_early = `b_early'
gen se_early = `se_early'
gen N_early = `N_early'
gen b_late = `b_late'
gen se_late = `se_late'
gen N_late = `N_late'

gen b_early_full = `b_early_full'
gen se_early_full = `se_early_full'
gen N_early_full = `N_early_full'
gen b_late_full = `b_late_full'
gen se_late_full = `se_late_full'
gen N_late_full = `N_late_full'

append using `jacktmp'
save `jacktmp', replace
}

restore
use `jacktmp', clear
drop if b_early==.
save "jack_knife_ypw_ag.dta", replace


use UseDataConvergence.dta, clear
xtset state year 
preserve
drop decade
tempfile jacktmp
save `jacktmp', emptyok replace
levelsof state, local(states)

foreach s of local states {

quietly levelsof statealpjack if state==`s', local(statename)

reg glypw_man lypw_man0 i.year  if year<=1910 & year>1800 & state!=`s', cl(id)

local b_early = _b[lypw_man0]
local se_early = _se[lypw_man0]
local N_early = e(N)

reg glypw_man lypw_man0 i.year  if year<=2020 & year>=1910 & state!=`s', cl(id)
local b_late = _b[lypw_man0]
local se_late = _se[lypw_man0]
local N_late = e(N)

reg glypw_agg lypw_agg0 i.year  if year<=1910 & year>1800, cl(id)

local b_early_full = _b[lypw_agg0]
local se_early_full = _se[lypw_agg0]
local N_early_full = e(N)

reg glypw_agg lypw_agg0 i.year  if year<=2020 & year>=1910, cl(id)
local b_late_full = _b[lypw_agg0]
local se_late_full = _se[lypw_agg0]
local N_late_full = e(N)

clear
set obs 1
gen str10 statename = `statename'
gen b_early = `b_early'
gen se_early = `se_early'
gen N_early = `N_early'
gen b_late = `b_late'
gen se_late = `se_late'
gen N_late = `N_late'

gen b_early_full = `b_early_full'
gen se_early_full = `se_early_full'
gen N_early_full = `N_early_full'
gen b_late_full = `b_late_full'
gen se_late_full = `se_late_full'
gen N_late_full = `N_late_full'

append using `jacktmp'
save `jacktmp', replace
}

restore
use `jacktmp', clear
drop if b_early==.
save "jack_knife_ypw_man.dta", replace


use UseDataConvergence.dta, clear
xtset state year 
preserve
drop decade
tempfile jacktmp
save `jacktmp', emptyok replace
levelsof state, local(states)

foreach s of local states {

quietly levelsof statealpjack if state==`s', local(statename)

reg glypw_nmna lypw_nmna0 i.year  if year<=1910 & year>1800 & state!=`s', cl(id)

local b_early = _b[lypw_nmna0]
local se_early = _se[lypw_nmna0]
local N_early = e(N)

reg glypw_nmna lypw_nmna0 i.year  if year<=2020 & year>=1910 & state!=`s', cl(id)
local b_late = _b[lypw_nmna0]
local se_late = _se[lypw_nmna0]
local N_late = e(N)

reg glypw_agg lypw_agg0 i.year  if year<=1910 & year>1800, cl(id)

local b_early_full = _b[lypw_agg0]
local se_early_full = _se[lypw_agg0]
local N_early_full = e(N)

reg glypw_agg lypw_agg0 i.year  if year<=2020 & year>=1910, cl(id)
local b_late_full = _b[lypw_agg0]
local se_late_full = _se[lypw_agg0]
local N_late_full = e(N)

clear
set obs 1
gen str10 statename = `statename'
gen b_early = `b_early'
gen se_early = `se_early'
gen N_early = `N_early'
gen b_late = `b_late'
gen se_late = `se_late'
gen N_late = `N_late'

gen b_early_full = `b_early_full'
gen se_early_full = `se_early_full'
gen N_early_full = `N_early_full'
gen b_late_full = `b_late_full'
gen se_late_full = `se_late_full'
gen N_late_full = `N_late_full'

append using `jacktmp'
save `jacktmp', replace
}

restore

use `jacktmp', clear
drop if b_early==.
save "jack_knife_ypw_nmna.dta", replace

use jack_knife_ypw_agg, clear
gen sector = "Aggregate"
append using jack_knife_ypw_ag
replace sector = "Agriculture" if missing(sector)
append using jack_knife_ypw_man
replace sector = "Industry" if missing(sector)
append using jack_knife_ypw_nmna
replace sector = "Services" if missing(sector)

save "jack_knife.dta", replace
use jack_knife, clear

use "jack_knife.dta", clear
levelsof sector, local(sectors)

capture erase "jack_knife_summary.dta"
capture erase "jack_knife_summary_Aggregate.dta"
capture erase "jack_knife_summary_Agriculture.dta"
capture erase "jack_knife_summary_Industry.dta"
capture erase "jack_knife_summary_Services.dta"
capture erase "state_knives.tex"

foreach sect of local sectors {
    preserve
    keep if sector == "`sect'"
	collapse (mean) b_early_mean = b_early ///
	(mean) b_late_mean = b_late ///
	(sd) b_sd_early = b_early ///
	(sd) b_sd_late = b_late ///
	(min) b_min_early = b_early /// 
	(min) b_min_late = b_late ///
	(max) b_max_early = b_early ///
	(max) b_max_late = b_late
	gen sector="`sect'"
	gen b_cvy_early = b_sd_early / b_early_mean 
	gen c_cvy_late = b_sd_late / b_late_mean
	save "jack_knife_summary_`sect'.dta"
	restore
}

use jack_knife_summary_Aggregate, clear
append using jack_knife_summary_Agriculture
append using jack_knife_summary_Industry
append using jack_knife_summary_Services
save "jack_knife_summary.dta", replace

// Export to LaTeX with mgroups
file open texfile using "`path_tabs'\knives_states.tex", write replace

// Write preamble and headers
file write texfile "\begin{tabular}{lcccccccc}" 
file write texfile "\toprule" 
file write texfile "& \multicolumn{4}{c}{1800-1910} & \multicolumn{4}{c}{1910-2020} \\" 
file write texfile "\cmidrule(lr){2-5} \cmidrule(lr){6-9}" _n
file write texfile "Sector & Mean $\beta$ & Std. dev. & Min & Max & Mean $\beta$ & Std. dev. & Min & Max \\" 
file write texfile "\midrule" 

// Write data rows
local N = _N
forvalues i = 1/`N' {
    file write texfile (sector[`i']) " & " ///
        %5.3f (b_early_mean[`i']) " & " ///
        %5.3f (b_sd_early[`i']) " & " ///
        %5.3f (b_min_early[`i']) " & " ///
        %5.3f (b_max_early[`i']) " & " ///
        %5.3f (b_late_mean[`i']) " & " ///
        %5.3f (b_sd_late[`i']) " & " ///
        %5.3f (b_min_late[`i']) " & " ///
        %5.3f (b_max_late[`i']) " \\"
}

// Write footer
file write texfile "\\bottomrule" _n
file write texfile "\\end{tabular}" _n
file close texfile

// JACK KNIVES AT THE CENSUS DIVISION LEVEL

use UseDataConvergence.dta, clear
xtset state year 
preserve
drop decade
tempfile jacktmp
save `jacktmp', emptyok replace
levelsof cendivjack, local(states)

foreach s of local states {

quietly levelsof cendivjack if cendivjack=="`s'", local(statename)

reg glypw_agg lypw_agg0 i.year  if year<=1910 & year>1800 & cendivjack!="`s'", cl(id)

local b_early = _b[lypw_agg0]
local se_early = _se[lypw_agg0]
local N_early = e(N)

reg glypw_agg lypw_agg0 i.year  if year<=2020 & year>=1910 & cendivjack!="`s'", cl(id)
local b_late = _b[lypw_agg0]
local se_late = _se[lypw_agg0]
local N_late = e(N)

reg glypw_agg lypw_agg0 i.year  if year<=1910 & year>1800, cl(id)

local b_early_full = _b[lypw_agg0]
local se_early_full = _se[lypw_agg0]
local N_early_full = e(N)

reg glypw_agg lypw_agg0 i.year  if year<=2020 & year>=1910, cl(id)
local b_late_full = _b[lypw_agg0]
local se_late_full = _se[lypw_agg0]
local N_late_full = e(N)

clear
set obs 1
gen str10 statename = `statename'
gen b_early = `b_early'
gen se_early = `se_early'
gen N_early = `N_early'
gen b_late = `b_late'
gen se_late = `se_late'
gen N_late = `N_late'

gen b_early_full = `b_early_full'
gen se_early_full = `se_early_full'
gen N_early_full = `N_early_full'
gen b_late_full = `b_late_full'
gen se_late_full = `se_late_full'
gen N_late_full = `N_late_full'

append using `jacktmp'
save `jacktmp', replace
}

restore
use `jacktmp', clear
drop if b_early==.
save "jack_knife_ypw_agg_census.dta", replace


use UseDataConvergence.dta, clear
xtset state year 
preserve
drop decade
tempfile jacktmp
save `jacktmp', emptyok replace
levelsof cendivjack, local(states)

foreach s of local states {

quietly levelsof cendivjack if cendivjack=="`s'", local(statename)

reg glypw_ag lypw_ag0 i.year  if year<=1910 & year>1800 & cendivjack!="`s'", cl(id)

local b_early = _b[lypw_ag0]
local se_early = _se[lypw_ag0]
local N_early = e(N)

reg glypw_ag lypw_ag0 i.year  if year<=2020 & year>=1910 & cendivjack!="`s'", cl(id)
local b_late = _b[lypw_ag0]
local se_late = _se[lypw_ag0]
local N_late = e(N)

reg glypw_ag lypw_ag0 i.year  if year<=1910 & year>1800, cl(id)

local b_early_full = _b[lypw_ag0]
local se_early_full = _se[lypw_ag0]
local N_early_full = e(N)

reg glypw_ag lypw_ag0 i.year  if year<=2020 & year>=1910, cl(id)
local b_late_full = _b[lypw_ag0]
local se_late_full = _se[lypw_ag0]
local N_late_full = e(N)

clear
set obs 1
gen str10 statename = `statename'
gen b_early = `b_early'
gen se_early = `se_early'
gen N_early = `N_early'
gen b_late = `b_late'
gen se_late = `se_late'
gen N_late = `N_late'

gen b_early_full = `b_early_full'
gen se_early_full = `se_early_full'
gen N_early_full = `N_early_full'
gen b_late_full = `b_late_full'
gen se_late_full = `se_late_full'
gen N_late_full = `N_late_full'

append using `jacktmp'
save `jacktmp', replace
}

restore
use `jacktmp', clear
drop if b_early==.
save "jack_knife_ypw_ag_census.dta", replace


use UseDataConvergence.dta, clear
xtset state year 
preserve
drop decade
tempfile jacktmp
save `jacktmp', emptyok replace
levelsof cendivjack, local(states)

foreach s of local states {

quietly levelsof cendivjack if cendivjack=="`s'", local(statename)

reg glypw_man lypw_man0 i.year  if year<=1910 & year>1800 & cendivjack!="`s'", cl(id)

local b_early = _b[lypw_man0]
local se_early = _se[lypw_man0]
local N_early = e(N)

reg glypw_man lypw_man0 i.year  if year<=2020 & year>=1910 & cendivjack!="`s'", cl(id)
local b_late = _b[lypw_man0]
local se_late = _se[lypw_man0]
local N_late = e(N)

reg glypw_man lypw_man0 i.year  if year<=1910 & year>1800, cl(id)

local b_early_full = _b[lypw_man0]
local se_early_full = _se[lypw_man0]
local N_early_full = e(N)

reg glypw_man lypw_man0 i.year  if year<=2020 & year>=1910, cl(id)
local b_late_full = _b[lypw_man0]
local se_late_full = _se[lypw_man0]
local N_late_full = e(N)

clear
set obs 1
gen str10 statename = `statename'
gen b_early = `b_early'
gen se_early = `se_early'
gen N_early = `N_early'
gen b_late = `b_late'
gen se_late = `se_late'
gen N_late = `N_late'

gen b_early_full = `b_early_full'
gen se_early_full = `se_early_full'
gen N_early_full = `N_early_full'
gen b_late_full = `b_late_full'
gen se_late_full = `se_late_full'
gen N_late_full = `N_late_full'

append using `jacktmp'
save `jacktmp', replace
}

restore
use `jacktmp', clear
drop if b_early==.
save "jack_knife_ypw_man_census.dta", replace


use UseDataConvergence.dta, clear
xtset state year 
preserve
drop decade
tempfile jacktmp
save `jacktmp', emptyok replace
levelsof cendivjack, local(states)

foreach s of local states {

quietly levelsof cendivjack if cendivjack=="`s'", local(statename)

reg glypw_nmna lypw_nmna0 i.year  if year<=1910 & year>1800 & cendivjack!="`s'", cl(id)

local b_early = _b[lypw_nmna0]
local se_early = _se[lypw_nmna0]
local N_early = e(N)

reg glypw_nmna lypw_nmna0 i.year  if year<=2020 & year>=1910 & cendivjack!="`s'", cl(id)
local b_late = _b[lypw_nmna0]
local se_late = _se[lypw_nmna0]
local N_late = e(N)

reg glypw_nmna lypw_nmna0 i.year  if year<=1910 & year>1800, cl(id)

local b_early_full = _b[lypw_nmna0]
local se_early_full = _se[lypw_nmna0]
local N_early_full = e(N)

reg glypw_nmna lypw_nmna0 i.year  if year<=2020 & year>=1910, cl(id)
local b_late_full = _b[lypw_nmna0]
local se_late_full = _se[lypw_nmna0]
local N_late_full = e(N)

clear
set obs 1
gen str10 statename = `statename'
gen b_early = `b_early'
gen se_early = `se_early'
gen N_early = `N_early'
gen b_late = `b_late'
gen se_late = `se_late'
gen N_late = `N_late'

gen b_early_full = `b_early_full'
gen se_early_full = `se_early_full'
gen N_early_full = `N_early_full'
gen b_late_full = `b_late_full'
gen se_late_full = `se_late_full'
gen N_late_full = `N_late_full'

append using `jacktmp'
save `jacktmp', replace
}

restore

use `jacktmp', clear
drop if b_early==.
save "jack_knife_ypw_nmna_census.dta", replace

use jack_knife_ypw_agg_census, clear
gen sector = "Aggregate"
append using jack_knife_ypw_ag_census
replace sector = "Agriculture" if missing(sector)
append using jack_knife_ypw_man_census
replace sector = "Industry" if missing(sector)
append using jack_knife_ypw_nmna_census
replace sector = "Services" if missing(sector)

save "jack_knife_census.dta", replace
use jack_knife_census, clear

gen upper_early = b_early+2*se_early
gen lower_early = b_early-2*se_early

gen upper_late = b_late+2*se_late
gen lower_late = b_late-2*se_late

summarize b_early if sector=="Aggregate"
local baseline_early_agg = r(mean)
summarize se_early if sector=="Aggregate"
local baseline_se_early_agg = r(mean)

summarize b_early if sector=="Agriculture"
local baseline_early_ag = r(mean)
summarize se_early if sector=="Agriculture"
local baseline_se_early_ag = r(mean)

summarize b_early if sector=="Industry"
local baseline_early_man = r(mean)
summarize se_early if sector=="Industry"
local baseline_se_early_man = r(mean)

summarize b_early if sector=="Services"
local baseline_early_nmna = r(mean)
summarize b_early if sector=="Services"
local baseline_se_early_nmna = r(mean)

gen baseline_upper_early_agg = `baseline_early_agg' + 2*`baseline_se_early_agg'
gen baseline_lower_early_agg = `baseline_early_agg' - 2*`baseline_se_early_agg'

gen baseline_upper_early_ag = `baseline_early_ag' + 2*`baseline_se_early_ag'
gen baseline_lower_early_ag = `baseline_early_ag' - 2*`baseline_se_early_ag'

gen baseline_upper_early_man = `baseline_early_man' + 2*`baseline_se_early_man'
gen baseline_lower_early_man = `baseline_early_man' - 2*`baseline_se_early_man'

gen baseline_upper_early_nmna = `baseline_early_nmna' + 2*`baseline_se_early_nmna'
gen baseline_lower_early_nmna = `baseline_early_nmna' - 2*`baseline_se_early_nmna'

summarize b_late if sector=="Aggregate"
local baseline_late_agg = r(mean)
summarize se_late if sector=="Aggregate"
local baseline_se_late_agg = r(mean)

summarize b_late if sector=="Agriculture"
local baseline_late_ag = r(mean)
summarize se_late if sector=="Agriculture"
local baseline_se_late_ag = r(mean)

summarize b_late if sector=="Industry"
local baseline_late_man = r(mean)
summarize se_late if sector=="Industry"
local baseline_se_late_man = r(mean)

summarize b_late if sector=="Services"
local baseline_late_nmna = r(mean)
summarize b_late if sector=="Services"
local baseline_se_late_nmna = r(mean)

gen baseline_upper_late_agg = `baseline_late_agg' + 2*`baseline_se_late_agg'
gen baseline_lower_late_agg = `baseline_late_agg' - 2*`baseline_se_late_agg'

gen baseline_upper_late_ag = `baseline_late_ag' + 2*`baseline_se_late_ag'
gen baseline_lower_late_ag = `baseline_late_ag' - 2*`baseline_se_late_ag'

gen baseline_upper_late_man = `baseline_late_man' + 2*`baseline_se_late_man'
gen baseline_lower_late_man = `baseline_late_man' - 2*`baseline_se_late_man'

gen baseline_upper_late_nmna = `baseline_late_nmna' + 2*`baseline_se_late_nmna'
gen baseline_lower_late_nmna = `baseline_late_nmna' - 2*`baseline_se_late_nmna'

use UseDataConvergence.dta, clear
xtset state year 
preserve
drop decade
tempfile jacktmp
save `jacktmp', emptyok replace
levelsof state, local(states)

foreach s of local states {

quietly levelsof statealpjack if state==`s', local(statename)

reg glypw_nmna lypw_nmna0 i.year  if year<=1910 & year>1800 & state!=`s', cl(id)

local b_early = _b[lypw_nmna0]
local se_early = _se[lypw_nmna0]
local N_early = e(N)

reg glypw_nmna lypw_nmna0 i.year  if year<=2020 & year>=1910 & state!=`s', cl(id)
local b_late = _b[lypw_nmna0]
local se_late = _se[lypw_nmna0]
local N_late = e(N)

reg glypw_agg lypw_agg0 i.year  if year<=1910 & year>1800, cl(id)

local b_early_full = _b[lypw_agg0]
local se_early_full = _se[lypw_agg0]
local N_early_full = e(N)

reg glypw_agg lypw_agg0 i.year  if year<=2020 & year>=1910, cl(id)
local b_late_full = _b[lypw_agg0]
local se_late_full = _se[lypw_agg0]
local N_late_full = e(N)

clear
set obs 1
gen str10 statename = `statename'
gen b_early = `b_early'
gen se_early = `se_early'
gen N_early = `N_early'
gen b_late = `b_late'
gen se_late = `se_late'
gen N_late = `N_late'

gen b_early_full = `b_early_full'
gen se_early_full = `se_early_full'
gen N_early_full = `N_early_full'
gen b_late_full = `b_late_full'
gen se_late_full = `se_late_full'
gen N_late_full = `N_late_full'

append using `jacktmp'
save `jacktmp', replace
}

restore

use `jacktmp', clear
drop if b_early==.
save "jack_knife_ypw_nmna.dta", replace

/// THIS COMMENTED OUT BLOCK IS BASICALLY NONSENSE WHERE I STARTED CALCULATING SOMETHING, REALIZED IT DIDN'T SHOW WHAT I PICTURED IN MY HEAD, BUT DIDN'T WANT TO TOSS THE CODE.
/// IT STAYS COMMENTED OUT AT ALL TIMES.

use jack_knife_ypw_agg_census, clear
gen sector = "Aggregate"
append using jack_knife_ypw_ag_census
replace sector = "Agriculture" if missing(sector)
append using jack_knife_ypw_man_census
replace sector = "Industry" if missing(sector)
append using jack_knife_ypw_nmna_census
replace sector = "Services" if missing(sector)

save "jack_knife_census.dta", replace
use jack_knife_census, clear

use "jack_knife_census.dta", clear
levelsof sector, local(sectors)

capture erase "jack_knife_census_summary.dta"
capture erase "jack_knife_census_summary_Aggregate.dta"
capture erase "jack_knife_census_summary_Agriculture.dta"
capture erase "jack_knife_census_summary_Industry.dta"
capture erase "jack_knife_census_summary_Services.dta"
capture erase "census_knives.tex"

foreach sect of local sectors {
    preserve
    keep if sector == "`sect'"
	collapse (mean) b_early_mean = b_early ///
	(mean) b_late_mean = b_late ///
	(sd) b_sd_early = b_early ///
	(sd) b_sd_late = b_late ///
	(min) b_min_early = b_early /// 
	(min) b_min_late = b_late ///
	(max) b_max_early = b_early ///
	(max) b_max_late = b_late
	gen sector="`sect'"
	gen b_cvy_early = b_sd_early / b_early_mean 
	gen c_cvy_late = b_sd_late / b_late_mean
	save "jack_knife_census_summary_`sect'.dta"
	restore
}

use jack_knife_census_summary_Aggregate, clear
append using jack_knife_census_summary_Agriculture
append using jack_knife_census_summary_Industry
append using jack_knife_census_summary_Services
save "jack_knife_census_summary.dta", replace

// Export to LaTeX with mgroups
file open texfile2 using "`path_tabs'\knives_divisions.tex", write replace

// Write preamble and headers
file write texfile2 "\begin{tabular}{lcccccccc}" 
file write texfile2 "\toprule" 
file write texfile2 "& \multicolumn{4}{c}{1800-1910} & \multicolumn{4}{c}{1910-2020} \\" 
file write texfile2 "\cmidrule(lr){2-5} \cmidrule(lr){6-9}" _n
file write texfile2 "Sector & Mean $\beta$ & Std. dev. & Min & Max & Mean $\beta$ & Std. dev. & Min & Max \\" 
file write texfile2 "\midrule" 

// Write data rows
local N = _N
forvalues i = 1/`N' {
    file write texfile2 (sector[`i']) " & " ///
        %5.3f (b_early_mean[`i']) " & " ///
        %5.3f (b_sd_early[`i']) " & " ///
        %5.3f (b_min_early[`i']) " & " ///
        %5.3f (b_max_early[`i']) " & " ///
        %5.3f (b_late_mean[`i']) " & " ///
        %5.3f (b_sd_late[`i']) " & " ///
        %5.3f (b_min_late[`i']) " & " ///
        %5.3f (b_max_late[`i']) " \\" _n
}


// Write footer
file write texfile2 "\\bottomrule" _n
file write texfile2 "\\end{tabular}" _n
file close texfile2

cd "$path_data"