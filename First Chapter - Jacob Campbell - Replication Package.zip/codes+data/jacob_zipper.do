
/*
================================================================================
REPLICATION PACKAGE ZIPPER
================================================================================
This script creates a complete, ready-to-use replication package with proper
folder structure. The resulting package can be zipped and distributed.

Output: A /zipper folder with everything organized and ready to run.
================================================================================
*/


******************************************
** Jacob: Setting paths, calling data **
******************************************

do "jacob_pathfinder.do"

// Also create locals for backward compatibility
local path "$path"
local path_data "$path_data"
local path_figs "$path_figs"
local path_legacy "$path_legacy"
local path_literature "$path_literature"
local path_log "$path_log"
local path_tabs "$path_tabs"
local path_zipper "$path_zipper"

di as result "Creating replication package in: $path_zipper"

// Create main zipper directory
cap mkdir "`path_zipper'"

// Create subdirectories in zipper
cap mkdir "`path_zipper'/codes+data"
cap mkdir "`path_zipper'/figures"
cap mkdir "`path_zipper'/legacy"
cap mkdir "`path_zipper'/literature"
cap mkdir "`path_zipper'/log"
cap mkdir "`path_zipper'/tables"
cap mkdir "`path_zipper'/zipper"


di as text "Folder structure created"

cd "$path"

// Copy README if it exists
cap confirm file "README.txt"
if !_rc {
    copy "README.txt" "`path_zipper'/README.txt", replace
    di as text "Copied README.txt"
}

    cap confirm file "jacob_replicate.do"
    if !_rc {
        copy "jacob_replicate.do" "`path_zipper'/jacob_replicate.do", replace
    }

cd "$path_data"

// Copy all jacob do-files to codes+data
local dofiles "pathfinder cartography convergence logger master summary tables transformer zipper jackknife compile"
foreach b of local dofiles {
    cap confirm file "jacob_`b'.do"
    if !_rc {
        copy "jacob_`b'.do" "`path_zipper'/codes+data/jacob_`b'.do", replace
        di as text "Copied jacob_`b'.do to codes+data/"
    }
}
	
// Copy data files to codes+data

local src "MotherFile.dta"
local dst "`path_zipper'/codes+data/MotherFile.dta"
copy "`src'" "`dst'", replace

local src "jacob_WorkerAge.dta"  
local dst "`path_zipper'/codes+data/jacob_WorkerAge.dta"
copy "`src'" "`dst'", replace

// Copy shapefile components for maps
local shpfiles "cb_2018_us_state_20m.shp cb_2018_us_state_20m.dbf cb_2018_us_state_20m.shx usdb.dta uscoord.dta"
foreach file of local shpfiles {
    cap confirm file "`path_data'/`file'"
    if !_rc {
        copy "`path_data'/`file'" "`path_zipper'/codes+data/`file'", replace
        di as text "Copied `file'"
    }
}

// Copy pre-generated jackknife tables to tables
copy "`path_tabs'/knives_states.tex" "`path_zipper'/tables/knives_states.tex", replace
di as text "Copied knives_states.tex"

copy "`path_tabs'/knives_divisions.tex" "`path_zipper'/tables/knives_divisions.tex", replace
di as text "Copied knives_divisions.tex"

// Copy LaTeX file to tables
copy "`path_tabs'/FirstChapter.ltx" "`path_zipper'/tables/FirstChapter.ltx", replace

cd "$path_data"